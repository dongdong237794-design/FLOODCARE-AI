# FLOODCARE AI v2.0 - Production Ready

ระบบแชทบอทอัจฉริยะสำหรับจัดการภัยน้ำท่วม ปรับปรุงประสิทธิภาพครั้งใหญ่ (Major Performance Upgrade)

---

## สารบัญ

1. [สิ่งที่ปรับปรุง](#whats-new)
2. [โครงสร้างไฟล์](#file-structure)
3. [การติดตั้ง](#installation)
4. [การตั้งค่า Environment Variables](#env-setup)
5. [การสร้าง LIFF App](#liff-setup)
6. [การ Deploy](#deployment)
7. [คู่มือการใช้งาน](#usage)
8. [ระบบ Intent Classification](#intent-system)
9. [ระบบ Cache](#cache-system)
10. [ระบบ Rate Limiting](#rate-limit)
11. [การ Troubleshoot](#troubleshoot)

---

## 1. สิ่งที่ปรับปรุง <a name="whats-new"></a>

### Performance ที่ดีขึ้น
| รายการ | Before | After | ปรับปรุง |
|---------|--------|-------|----------|
| Gemini API Calls | ทุกข้อความ | เฉพาะ AI Query | -80% Token |
| Response Time | 3-10 วินาที | 1-2 วินาที | 60-80% |
| Sheets Reads | ทุก Request | Memory Cache | -90% Reads |
| State Machine | if-elif ยาว | Class-based | อ่านง่าย |
| Memory Leak | ไม่มี TTL | Auto-cleanup 30 นาที | เสถียร |

### Architecture ใหม่
- **Intent Classification System** - แยกข้อความก่อนส่ง AI
- **Multi-Layer Cache** - Memory LRU + TTL Cache
- **Session Manager** - Class-based พร้อม Auto-cleanup
- **Rate Limiter** - Token bucket algorithm
- **Structured Logging** - ติดตาม Performance
- **Sheets Manager** - Batch writes, connection pooling

### SOS LIFF ที่ครบถ้วน
1. ดึง GPS อัตโนมัติ
2. เลือกระดับเหตุ (วิกฤต/สูง/ปานกลาง/ต่ำ)
3. จำนวนผู้ประสบภัย
4. กลุ่มเปราะบาง (เด็ก/ผู้สูงอายุ/ผู้พิการ/ผู้ป่วยติดเตียง/หญิงตั้งครรภ์/สัตว์เลี้ยง)
5. รายละเอียด + รูปภาพ
6. หน้าสรุป + ยืนยัน
7. เลขเคสอ้างอิง

### Needs LIFF ที่ครบถ้วน
1. 11 หมวดหมู่สิ่งของ (อาหาร/น้ำ/ยา/ของใช้/เครื่องนอน/เสื้อผ้า/ไฟฉาย/PowerBank/เด็กอ่อน/สัตว์เลี้ยง/อื่นๆ)
2. ตัวเลือกอาหารฮาลาล
3. พิมพ์รายละเอียดเอง
4. 3 ระดับความเร่งด่วน
5. หน้าสรุป + ยืนยัน

---

## 2. โครงสร้างไฟล์ <a name="file-structure"></a>

```
floodcare-ai/
├── app.py              # Flask App หลัก (Webhook, Routes, API)
├── bot_config.py       # Config, Cache, Gemini, State Machine
├── sos_liff.py         # SOS LIFF HTML (แจ้งเหตุฉุกเฉิน)
├── need_liff.py        # Needs LIFF HTML (ขอความช่วยเหลือ)
├── requirements.txt    # Python Dependencies
└── README.md           # คู่มือนี้
```

---

## 3. การติดตั้ง <a name="installation"></a>

### 3.1 ติดตั้ง Dependencies

```bash
pip install -r requirements.txt
```

หรือติดตั้งทีละ package:

```bash
pip install flask line-bot-sdk google-generativeai gspread google-auth requests supabase python-dotenv
```

### 3.2 โครงสร้าง Google Sheets

ระบบจะสร้าง Sheets อัตโนมัติ แต่ต้องมี Sheet หลักที่มีชีตดังนี้:
- `users` - ข้อมูลผู้ใช้
- `sos_requests` - รายการ SOS
- `user_needs` - ความต้องการสิ่งของ
- `Shelters` - ศูนย์พักพิง
- `Water_Levels` - ระดับน้ำ
- `Contacts` - เบอร์ติดต่อ
- `AI_Logs` - บันทึก AI
- `System_Logs` - บันทึกระบบ

---

## 4. การตั้งค่า Environment Variables <a name="env-setup"></a>

สร้างไฟล์ `.env` หรือตั้งค่าใน Hosting:

```env
# LINE Configuration (จำเป็น)
LINE_CHANNEL_ACCESS_TOKEN=your_line_channel_access_token
LINE_CHANNEL_SECRET=your_line_channel_secret

# Gemini AI (จำเป็น)
GEMINI_API_KEY=your_gemini_api_key

# Google Sheets (จำเป็น)
GOOGLE_SHEET_ID=your_google_sheet_id
GOOGLE_SERVICE_ACCOUNT_JSON={"type":"service_account",...}

# TMD Weather API (แนะนำ)
TMD_ACCESS_TOKEN=your_tmd_token

# LIFF Configuration
SOS_LIFF_ID=your_sos_liff_id
SOS_LIFF_URL=https://liff.line.me/your_sos_liff_id
NEED_LIFF_ID=your_need_liff_id
NEED_LIFF_URL=https://liff.line.me/your_need_liff_id

# Performance Tuning (optional)
WATER_DATA_MAX_AGE_MINUTES=10
CACHE_TTL_SECONDS=300
RATE_LIMIT_REQUESTS=30
RATE_LIMIT_WINDOW=60
SESSION_TTL_MINUTES=30
```

### วิธีการเอา GOOGLE_SERVICE_ACCOUNT_JSON:
1. ไปที่ [Google Cloud Console](https://console.cloud.google.com/)
2. APIs & Services > Credentials > Create Service Account
3. สร้าง Key แบบ JSON
4. เปิดไฟล์ JSON แล้ว copy ทั้งหมดใส่ใน environment variable

---

## 5. การสร้าง LIFF App <a name="liff-setup"></a>

### 5.1 SOS LIFF
1. ไปที่ [LINE Developers Console](https://developers.line.biz/)
2. เลือก Provider > Channel
3. เมนู **LIFF** > **Add**
4. ตั้งค่า:
   - LIFF app name: `FLOODCARE SOS`
   - Size: `Full`
   - Endpoint URL: `https://your-app.herokuapp.com/liff/sos`
   - เช็คถูก `profile`, `chat_message.write`
5. คัดลอก LIFF ID ไปใส่ใน `SOS_LIFF_ID`
6. URL จะเป็น: `https://liff.line.me/{LIFF_ID}`

### 5.2 Needs LIFF
1. เมนู **LIFF** > **Add**
2. ตั้งค่า:
   - LIFF app name: `FLOODCARE Needs`
   - Size: `Full`
   - Endpoint URL: `https://your-app.herokuapp.com/liff/need`
3. คัดลอก LIFF ID ไปใส่ใน `NEED_LIFF_ID`

---

## 6. การ Deploy <a name="deployment"></a>

### 6.1 Heroku
```bash
# สร้าง Procfile
echo "web: python app.py" > Procfile

# Heroku CLI
heroku create your-floodcare-app
heroku config:set LINE_CHANNEL_ACCESS_TOKEN=xxx
heroku config:set LINE_CHANNEL_SECRET=xxx
heroku config:set GEMINI_API_KEY=xxx
heroku config:set GOOGLE_SHEET_ID=xxx
heroku config:set GOOGLE_SERVICE_ACCOUNT_JSON='{...}'

git push heroku main
```

### 6.2 Render
1. New Web Service > Connect GitHub
2. Build Command: `pip install -r requirements.txt`
3. Start Command: `python app.py`
4. Add Environment Variables ทั้งหมด

### 6.3 Railway / Fly.io / DigitalOcean
ใช้ Dockerfile หรือติดตั้งตาม template ของแต่ละ platform

---

## 7. คู่มือการใช้งาน <a name="usage"></a>

### 7.1 สำหรับผู้ใช้ทั่วไป
พิมพ์ข้อความใน LINE:
- **ทักทาย**: "สวัสดี", "หวัดดี", "hello"
- **SOS**: "sos", "ขอความช่วยเหลือ", "🆘"
- **ความต้องการ**: "ขอของ", "ต้องการ", "ขาดแคลน"
- **เบอร์โทร**: "เบอร์ฉุกเฉิน", "1784"
- **ศูนย์พักพิง**: "ศูนย์พักพิง", "หาที่พัก"
- **ระดับน้ำ**: "ระดับน้ำ", "น้ำท่วม"
- **สภาพอากาศ**: "อากาศ", "ฝน"
- **ถาม AI**: พิมพ์คำถามทั่วไป
- **ยกเลิก**: "ยกเลิก"
- **เปลี่ยนภาษา**: "เปลี่ยนภาษา"

### 7.2 สำหรับเจ้าหน้าที่
**Debug Endpoints:**
```
GET  /debug/status      # สถานะระบบ, cache, sessions
GET  /debug/sync-status # สถานะข้อมูลระดับน้ำ
POST /debug/force-sync  # บังคับ sync ข้อมูล
GET  /debug/logs        # ดู logs ล่าสุด
```

---

## 8. ระบบ Intent Classification <a name="intent-system"></a>

ระบบจำแนกข้อความอัตโนมัติเพื่อลดการเรียก Gemini API:

| Intent | คำสั่งที่รองรับ | การตอบสนอง |
|--------|----------------|------------|
| GREETING | สวัสดี, hello, hi | ทักทาย + เมนู |
| SOS | sos, ขอความช่วยเหลือ | เปิด SOS flow |
| EMERGENCY | ช่วยด้วย, จะตาย | คำแนะนำฉุกเฉินทันที |
| NEEDS | ขอของ, ต้องการ | เปิด Needs flow |
| SHELTER | ศูนย์พักพิง, ที่พัก | ค้นหาศูนย์พักพิง |
| WATER_LEVEL | ระดับน้ำ, น้ำท่วม | เช็คระดับน้ำ |
| WEATHER | อากาศ, ฝน | พยากรณ์อากาศ |
| CONTACT | เบอร์, โทรศัพท์ | เบอร์ฉุกเฉิน |
| AI_QUERY | คำถามทั่วไป | ส่งให้ Gemini |

**ประหยัด Token ~80%** เพราะข้อความส่วนใหญ่ไม่ต้องผ่าน AI

---

## 9. ระบบ Cache <a name="cache-system"></a>

Multi-layer cache อัตโนมัติ:
- **General Cache** - API responses (5 นาที)
- **Weather Cache** - ข้อมูลอากาศ (30 นาที)
- **Water Cache** - ระดับน้ำ (15 นาที)
- **Sessions Cache** - ข้อมูลผู้ใช้ (30 นาที)
- **Sheets Cache** - ข้อมูล Sheets (10 นาที)

---

## 10. ระบบ Rate Limiting <a name="rate-limit"></a>

จำกัดการใช้งาน: **30 requests / 60 seconds / user**
- ป้องกัน Spam
- ลดค่าใช้จ่าย API
- ป้องกันการโจมตี

---

## 11. การ Troubleshoot <a name="troubleshoot"></a>

| ปัญหา | สาเหตุ | แก้ไข |
|-------|--------|-------|
| AI ไม่ตอบ | GEMINI_API_KEY ไม่ถูกต้อง | ตรวจสอบ API Key |
| Sheets ไม่บันทึก | JSON Key ผิด | ตรวจสอบ GOOGLE_SERVICE_ACCOUNT_JSON |
| GPS ไม่ทำงาน | ไม่อนุญาต Location | เปิด Permission ในเบราว์เซอร์ |
| LIFF ไม่เปิด | LIFF ID ผิด | ตรวจสอบ LIFF ID ใน Console |
| ระบบช้า | Cache miss | ตรวจสอบ /debug/status |

---

## License

MIT License - ใช้สำหรับช่วยเหลือผู้ประสบภัยน้ำท่วม

## Contact

FLOODCARE AI Team
