"""
FLOODCARE AI - SOS LIFF (LINE Front-end Framework)
====================================================
Full-featured SOS emergency reporting form with:
- GPS auto-detection
- Water level severity selection
- Victim count input
- Vulnerable group selection (children, elderly, disabled, bedridden)
- Photo upload
- Summary and confirmation
- SMS backup notification

UX Design:
- Large buttons for elderly users (min 60px height)
- High contrast colors
- Clear step-by-step flow
- Font size 18px minimum
- Voice-friendly labels

Usage:
1. Create LIFF app in LINE Developers Console
2. Set endpoint URL to: https://your-app.herokuapp.com/liff/sos
3. Set LIFF_ID in environment variables
"""

# This file contains both the Python constant and serves the HTML
# The HTML is extracted by app.py for the /liff/sos route

SOS_LIFF_HTML = """
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>SOS แจ้งเหตุฉุกเฉิน - FLOODCARE AI</title>
    <script src="https://static.line-scdn.net/liff/edge/2/sdk.js"></script>
    <style>
        /* ============================================
           DESIGN SYSTEM - Elderly & Emergency Optimized
           ============================================ */
        :root {
            --danger: #DC2626;
            --danger-dark: #991B1B;
            --danger-light: #FEE2E2;
            --warning: #F59E0B;
            --warning-light: #FEF3C7;
            --success: #059669;
            --success-light: #D1FAE5;
            --info: #2563EB;
            --info-light: #DBEAFE;
            --gray-50: #F9FAFB;
            --gray-100: #F3F4F6;
            --gray-200: #E5E7EB;
            --gray-300: #D1D5DB;
            --gray-400: #9CA3AF;
            --gray-500: #6B7280;
            --gray-600: #4B5563;
            --gray-700: #374151;
            --gray-800: #1F2937;
            --gray-900: #111827;
            --font-size-base: 20px;
            --font-size-lg: 24px;
            --font-size-xl: 28px;
            --btn-height: 64px;
            --btn-height-lg: 72px;
            --spacing-xs: 8px;
            --spacing-sm: 12px;
            --spacing-md: 16px;
            --spacing-lg: 24px;
            --spacing-xl: 32px;
            --radius: 16px;
            --radius-lg: 20px;
        }

        * { 
            box-sizing: border-box; 
            margin: 0; 
            padding: 0; 
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Sukhumvit Set', 'Kanit', sans-serif;
            font-size: var(--font-size-base);
            line-height: 1.6;
            color: var(--gray-800);
            background: var(--gray-50);
            min-height: 100vh;
            padding-bottom: 40px;
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, var(--danger) 0%, var(--danger-dark) 100%);
            color: white;
            padding: var(--spacing-lg) var(--spacing-md);
            text-align: center;
            position: sticky;
            top: 0;
            z-index: 100;
            box-shadow: 0 4px 20px rgba(220, 38, 38, 0.3);
        }
        .header h1 {
            font-size: var(--font-size-xl);
            font-weight: 700;
            margin-bottom: 4px;
        }
        .header p {
            font-size: var(--font-size-base);
            opacity: 0.9;
        }

        /* Progress Steps */
        .progress-bar {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: var(--spacing-md);
            background: white;
            border-bottom: 1px solid var(--gray-200);
            gap: 4px;
        }
        .step {
            display: flex;
            align-items: center;
            gap: 4px;
        }
        .step-dot {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: var(--gray-300);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            font-weight: 700;
            transition: all 0.3s ease;
        }
        .step-dot.active {
            background: var(--danger);
            box-shadow: 0 0 0 4px var(--danger-light);
        }
        .step-dot.completed {
            background: var(--success);
        }
        .step-line {
            width: 30px;
            height: 3px;
            background: var(--gray-300);
            border-radius: 2px;
        }
        .step-line.completed {
            background: var(--success);
        }
        .step-label {
            font-size: 12px;
            color: var(--gray-500);
            text-align: center;
            margin-top: 4px;
        }

        /* Container */
        .container {
            max-width: 480px;
            margin: 0 auto;
            padding: var(--spacing-lg) var(--spacing-md);
        }

        /* Cards */
        .card {
            background: white;
            border-radius: var(--radius-lg);
            padding: var(--spacing-lg);
            margin-bottom: var(--spacing-lg);
            box-shadow: 0 2px 12px rgba(0,0,0,0.08);
            border: 1px solid var(--gray-200);
        }
        .card-title {
            font-size: var(--font-size-lg);
            font-weight: 700;
            color: var(--gray-800);
            margin-bottom: var(--spacing-sm);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .card-subtitle {
            font-size: var(--font-size-base);
            color: var(--gray-500);
            margin-bottom: var(--spacing-md);
        }

        /* Form Elements */
        .form-group {
            margin-bottom: var(--spacing-lg);
        }
        .form-label {
            display: block;
            font-size: var(--font-size-lg);
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: var(--spacing-sm);
        }
        .form-input {
            width: 100%;
            height: var(--btn-height);
            padding: 0 var(--spacing-md);
            font-size: var(--font-size-lg);
            border: 2px solid var(--gray-300);
            border-radius: var(--radius);
            background: var(--gray-50);
            transition: border-color 0.2s;
            -webkit-appearance: none;
        }
        .form-input:focus {
            outline: none;
            border-color: var(--danger);
            background: white;
        }
        textarea.form-input {
            height: 120px;
            padding: var(--spacing-md);
            resize: vertical;
        }

        /* Buttons */
        .btn {
            width: 100%;
            height: var(--btn-height);
            font-size: var(--font-size-lg);
            font-weight: 600;
            border: none;
            border-radius: var(--radius);
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            margin-bottom: var(--spacing-sm);
            -webkit-appearance: none;
        }
        .btn:active {
            transform: scale(0.98);
        }
        .btn-danger {
            background: var(--danger);
            color: white;
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
        }
        .btn-danger:hover { background: var(--danger-dark); }
        .btn-success {
            background: var(--success);
            color: white;
            box-shadow: 0 4px 12px rgba(5, 150, 105, 0.3);
        }
        .btn-outline {
            background: white;
            color: var(--gray-700);
            border: 2px solid var(--gray-300);
        }
        .btn-outline:hover { border-color: var(--danger); }
        .btn-lg {
            height: var(--btn-height-lg);
            font-size: var(--font-size-xl);
        }

        /* Selection Buttons */
        .select-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: var(--spacing-sm);
        }
        .select-btn {
            padding: var(--spacing-md);
            border: 2px solid var(--gray-300);
            border-radius: var(--radius);
            background: white;
            font-size: var(--font-size-base);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-align: center;
            min-height: var(--btn-height);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }
        .select-btn.selected {
            border-color: var(--danger);
            background: var(--danger-light);
            color: var(--danger-dark);
        }
        .select-btn:active {
            transform: scale(0.97);
        }

        /* Severity Levels */
        .severity-grid {
            display: grid;
            gap: var(--spacing-sm);
        }
        .severity-btn {
            padding: var(--spacing-md) var(--spacing-lg);
            border: 3px solid;
            border-radius: var(--radius);
            background: white;
            font-size: var(--font-size-lg);
            font-weight: 700;
            cursor: pointer;
            transition: all 0.2s;
            text-align: left;
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
        }
        .severity-btn.critical {
            border-color: var(--danger);
            color: var(--danger);
        }
        .severity-btn.critical.selected {
            background: var(--danger);
            color: white;
        }
        .severity-btn.high {
            border-color: var(--warning);
            color: #92400E;
        }
        .severity-btn.high.selected {
            background: var(--warning);
            color: white;
        }
        .severity-btn.medium {
            border-color: #D97706;
            color: #92400E;
        }
        .severity-btn.medium.selected {
            background: #D97706;
            color: white;
        }
        .severity-btn.low {
            border-color: var(--success);
            color: var(--success);
        }
        .severity-btn.low.selected {
            background: var(--success);
            color: white;
        }

        /* Vulnerable Groups */
        .group-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: var(--spacing-sm);
        }
        .group-btn {
            padding: var(--spacing-lg);
            border: 2px solid var(--gray-300);
            border-radius: var(--radius);
            background: white;
            font-size: var(--font-size-base);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s;
            text-align: center;
        }
        .group-btn.selected {
            border-color: var(--info);
            background: var(--info-light);
            color: var(--info);
        }
        .group-btn .icon {
            font-size: 32px;
            display: block;
            margin-bottom: 4px;
        }

        /* Number Input */
        .number-control {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: var(--spacing-lg);
        }
        .number-btn {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            border: 2px solid var(--gray-300);
            background: white;
            font-size: var(--font-size-xl);
            font-weight: 700;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .number-btn:active { background: var(--gray-100); }
        .number-display {
            font-size: 48px;
            font-weight: 700;
            color: var(--danger);
            min-width: 80px;
            text-align: center;
        }

        /* GPS Status */
        .gps-status {
            padding: var(--spacing-md);
            border-radius: var(--radius);
            text-align: center;
            font-size: var(--font-size-base);
            margin-bottom: var(--spacing-md);
        }
        .gps-status.loading {
            background: var(--info-light);
            color: var(--info);
        }
        .gps-status.success {
            background: var(--success-light);
            color: var(--success);
        }
        .gps-status.error {
            background: var(--danger-light);
            color: var(--danger);
        }

        /* Summary */
        .summary-item {
            display: flex;
            justify-content: space-between;
            padding: var(--spacing-sm) 0;
            border-bottom: 1px solid var(--gray-200);
            font-size: var(--font-size-base);
        }
        .summary-label {
            font-weight: 600;
            color: var(--gray-600);
        }
        .summary-value {
            color: var(--gray-800);
            font-weight: 700;
        }

        /* Photo Upload */
        .photo-upload {
            border: 3px dashed var(--gray-300);
            border-radius: var(--radius-lg);
            padding: var(--spacing-xl);
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .photo-upload:hover {
            border-color: var(--danger);
            background: var(--danger-light);
        }
        .photo-preview {
            max-width: 100%;
            border-radius: var(--radius);
            margin-top: var(--spacing-sm);
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in {
            animation: fadeIn 0.3s ease;
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); }
            50% { transform: scale(1.05); }
        }
        .pulse {
            animation: pulse 2s infinite;
        }

        /* Hidden */
        .hidden { display: none !important; }

        /* Loading */
        .spinner {
            width: 40px;
            height: 40px;
            border: 4px solid var(--gray-300);
            border-top-color: var(--danger);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* Success Screen */
        .success-screen {
            text-align: center;
            padding: var(--spacing-xl) 0;
        }
        .success-icon {
            font-size: 80px;
            margin-bottom: var(--spacing-md);
        }
        .case-number {
            font-size: 32px;
            font-weight: 700;
            color: var(--danger);
            background: var(--danger-light);
            padding: var(--spacing-sm) var(--spacing-lg);
            border-radius: var(--radius);
            display: inline-block;
            margin: var(--spacing-sm) 0;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <div class="header">
        <h1>🚨 แจ้งเหตุฉุกเฉิน SOS</h1>
        <p>FLOODCARE AI - ระบบแจ้งเหตุน้ำท่วม</p>
    </div>

    <!-- Progress Steps -->
    <div class="progress-bar">
        <div class="step">
            <div class="step-dot active" id="step1-dot">1</div>
            <div class="step-label">GPS</div>
        </div>
        <div class="step-line" id="line1"></div>
        <div class="step">
            <div class="step-dot" id="step2-dot">2</div>
            <div class="step-label">ระดับ</div>
        </div>
        <div class="step-line" id="line2"></div>
        <div class="step">
            <div class="step-dot" id="step3-dot">3</div>
            <div class="step-label">จำนวน</div>
        </div>
        <div class="step-line" id="line3"></div>
        <div class="step">
            <div class="step-dot" id="step4-dot">4</div>
            <div class="step-label">กลุ่ม</div>
        </div>
        <div class="step-line" id="line4"></div>
        <div class="step">
            <div class="step-dot" id="step5-dot">5</div>
            <div class="step-label">ยืนยัน</div>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container">

        <!-- ========== STEP 1: GPS Location ========== -->
        <div id="step1" class="fade-in">
            <div class="card">
                <div class="card-title">📍 ขั้นตอนที่ 1: ตำแหน่งของคุณ</div>
                <div class="card-subtitle">ระบบจะดึงพิกัด GPS อัตโนมัติ หรือกดปุ่มด้านล่าง</div>
                
                <div class="gps-status loading" id="gpsStatus">
                    <div class="spinner" style="display:inline-block; width:24px; height:24px; margin-right:8px;"></div>
                    กำลังระบุตำแหน่ง...
                </div>
                
                <div id="gpsResult" class="hidden">
                    <div class="summary-item">
                        <span class="summary-label">ละติจูด</span>
                        <span class="summary-value" id="latValue">-</span>
                    </div>
                    <div class="summary-item">
                        <span class="summary-label">ลองจิจูด</span>
                        <span class="summary-value" id="lonValue">-</span>
                    </div>
                    <div class="summary-item">
                        <span class="summary-label">ที่อยู่โดยประมาณ</span>
                        <span class="summary-value" id="addressValue">-</span>
                    </div>
                </div>

                <button class="btn btn-danger btn-lg pulse" id="btnGetGPS" onclick="getGPS()">
                    📍 ดึงพิกัด GPS
                </button>
                <button class="btn btn-success hidden" id="btnNext1" onclick="goToStep(2)">
                    ถัดไป ➡️
                </button>
            </div>
        </div>

        <!-- ========== STEP 2: Severity Level ========== -->
        <div id="step2" class="hidden">
            <div class="card">
                <div class="card-title">🌊 ขั้นตอนที่ 2: ระดับความรุนแรง</div>
                <div class="card-subtitle">เลือกระดับสถานการณ์น้ำท่วมปัจจุบัน</div>

                <div class="severity-grid">
                    <button class="severity-btn critical" onclick="selectSeverity('critical', 'วิกฤต - มิดหัว/ติดหลังคา')">
                        <span>🔴</span>
                        <div>
                            <div style="font-size:22px;">วิกฤต</div>
                            <div style="font-size:16px; font-weight:400;">มิดหัว / ติดหลังคา</div>
                        </div>
                    </button>
                    <button class="severity-btn high" onclick="selectSeverity('high', 'สูง - ระดับอก/เกิน 1 เมตร')">
                        <span>🟠</span>
                        <div>
                            <div style="font-size:22px;">สูง</div>
                            <div style="font-size:16px; font-weight:400;">ระดับอก / เกิน 1 เมตร</div>
                        </div>
                    </button>
                    <button class="severity-btn medium" onclick="selectSeverity('medium', 'ปานกลาง - ระดับเอว')">
                        <span>🟡</span>
                        <div>
                            <div style="font-size:22px;">ปานกลาง</div>
                            <div style="font-size:16px; font-weight:400;">ระดับเอว</div>
                        </div>
                    </button>
                    <button class="severity-btn low" onclick="selectSeverity('low', 'ต่ำ - ระดับหน้าแข้ง')">
                        <span>🟢</span>
                        <div>
                            <div style="font-size:22px;">ต่ำ</div>
                            <div style="font-size:16px; font-weight:400;">ระดับหน้าแข้ง</div>
                        </div>
                    </button>
                </div>

                <button class="btn btn-outline" onclick="goToStep(1)" style="margin-top:var(--spacing-md);">
                    ⬅️ กลับ
                </button>
            </div>
        </div>

        <!-- ========== STEP 3: Victim Count ========== -->
        <div id="step3" class="hidden">
            <div class="card">
                <div class="card-title">👥 ขั้นตอนที่ 3: จำนวนผู้ประสบภัย</div>
                <div class="card-subtitle">ระบุจำนวนคนที่ต้องการความช่วยเหลือ</div>

                <div style="text-align:center; padding: var(--spacing-xl) 0;">
                    <div class="number-control">
                        <button class="number-btn" onclick="changeCount(-1)">−</button>
                        <div class="number-display" id="victimCount">1</div>
                        <button class="number-btn" onclick="changeCount(1)">+</button>
                    </div>
                    <div style="color: var(--gray-500); margin-top: var(--spacing-sm); font-size: var(--font-size-base);">
                        คน
                    </div>
                </div>

                <button class="btn btn-success btn-lg" onclick="goToStep(4)">
                    ถัดไป ➡️
                </button>
                <button class="btn btn-outline" onclick="goToStep(2)">
                    ⬅️ กลับ
                </button>
            </div>
        </div>

        <!-- ========== STEP 4: Vulnerable Groups ========== -->
        <div id="step4" class="hidden">
            <div class="card">
                <div class="card-title">⚠️ ขั้นตอนที่ 4: กลุ่มเปราะบาง</div>
                <div class="card-subtitle">เลือกกลุ่มที่ต้องการดูแลเป็นพิเศษ (เลือกได้หลายกลุ่ม)</div>

                <div class="group-grid">
                    <button class="group-btn" id="group-child" onclick="toggleGroup('child', 'เด็กเล็ก')">
                        <span class="icon">👶</span>
                        <div>เด็กเล็ก</div>
                    </button>
                    <button class="group-btn" id="group-elderly" onclick="toggleGroup('elderly', 'ผู้สูงอายุ')">
                        <span class="icon">🧓</span>
                        <div>ผู้สูงอายุ</div>
                    </button>
                    <button class="group-btn" id="group-disabled" onclick="toggleGroup('disabled', 'ผู้พิการ')">
                        <span class="icon">♿</span>
                        <div>ผู้พิการ</div>
                    </button>
                    <button class="group-btn" id="group-bedridden" onclick="toggleGroup('bedridden', 'ผู้ป่วยติดเตียง')">
                        <span class="icon">🛏️</span>
                        <div>ผู้ป่วยติดเตียง</div>
                    </button>
                    <button class="group-btn" id="group-pregnant" onclick="toggleGroup('pregnant', 'หญิงตั้งครรภ์')">
                        <span class="icon">🤰</span>
                        <div>หญิงตั้งครรภ์</div>
                    </button>
                    <button class="group-btn" id="group-pet" onclick="toggleGroup('pet', 'สัตว์เลี้ยง')">
                        <span class="icon">🐕</span>
                        <div>สัตว์เลี้ยง</div>
                    </button>
                </div>

                <div style="margin-top: var(--spacing-lg);">
                    <div class="form-label">📝 รายละเอียดเพิ่มเติม</div>
                    <textarea class="form-input" id="detailsInput" placeholder="เช่น น้ำท่วมถึงชั้น 2 ต้องการเรือยาง คนป่วยต้องใช้ออกซิเจน..."></textarea>
                </div>

                <div style="margin-top: var(--spacing-md);">
                    <div class="form-label">📷 รูปภาพสถานการณ์ (ถ้ามี)</div>
                    <div class="photo-upload" onclick="document.getElementById('photoInput').click()">
                        <div style="font-size: 40px;">📷</div>
                        <div>แตะเพื่อเลือกรูปภาพ</div>
                    </div>
                    <input type="file" id="photoInput" accept="image/*" capture="environment" style="display:none" onchange="handlePhoto(this)">
                    <img id="photoPreview" class="photo-preview hidden">
                </div>

                <button class="btn btn-success btn-lg" style="margin-top:var(--spacing-lg);" onclick="goToStep(5)">
                    ถัดไป ➡️
                </button>
                <button class="btn btn-outline" onclick="goToStep(3)">
                    ⬅️ กลับ
                </button>
            </div>
        </div>

        <!-- ========== STEP 5: Summary & Confirm ========== -->
        <div id="step5" class="hidden">
            <div class="card">
                <div class="card-title">📋 ขั้นตอนที่ 5: สรุปข้อมูล</div>
                <div class="card-subtitle">ตรวจสอบข้อมูลก่อนส่ง</div>

                <div id="summaryContent">
                    <div class="summary-item">
                        <span class="summary-label">📍 พิกัด</span>
                        <span class="summary-value" id="sumGPS">-</span>
                    </div>
                    <div class="summary-item">
                        <span class="summary-label">🌊 ระดับความรุนแรง</span>
                        <span class="summary-value" id="sumSeverity">-</span>
                    </div>
                    <div class="summary-item">
                        <span class="summary-label">👥 จำนวนผู้ประสบภัย</span>
                        <span class="summary-value" id="sumCount">-</span>
                    </div>
                    <div class="summary-item">
                        <span class="summary-label">⚠️ กลุ่มเปราะบาง</span>
                        <span class="summary-value" id="sumGroups">-</span>
                    </div>
                    <div class="summary-item">
                        <span class="summary-label">📝 รายละเอียด</span>
                        <span class="summary-value" id="sumDetails">-</span>
                    </div>
                </div>

                <button class="btn btn-danger btn-lg pulse" id="btnSubmit" onclick="submitSOS()">
                    🚨 ยืนยันส่งข้อมูล
                </button>
                <button class="btn btn-outline" onclick="goToStep(4)">
                    ⬅️ กลับแก้ไข
                </button>
            </div>
        </div>

        <!-- ========== SUCCESS SCREEN ========== -->
        <div id="successScreen" class="hidden">
            <div class="card success-screen">
                <div class="success-icon">✅</div>
                <h2 style="font-size: var(--font-size-xl); color: var(--success); margin-bottom: var(--spacing-sm);">
                    ส่งข้อมูลสำเร็จ!
                </h2>
                <p style="color: var(--gray-600); margin-bottom: var(--spacing-sm);">
                    เลขเคสของคุณ:
                </p>
                <div class="case-number" id="caseId">-</div>
                <p style="color: var(--gray-600); margin-top: var(--spacing-md); line-height: 1.8;">
                    ทีมกู้ภัยกำลังเดินทางมาช่วยเหลือ<br>
                    กรุณาอยู่ในที่ปลอดภัย
                </p>
                <div style="margin-top: var(--spacing-lg); padding: var(--spacing-md); background: var(--danger-light); border-radius: var(--radius); text-align: left; font-size: var(--font-size-base);">
                    <div style="font-weight: 700; color: var(--danger); margin-bottom: var(--spacing-sm);">
                        🛡️ ขั้นตอนเอาตัวรอดขณะรอ:
                    </div>
                    <div style="color: var(--gray-700); line-height: 2;">
                        1. ตัดสะพานไฟในบ้านทันที<br>
                        2. พยายามอยู่บนที่สูง<br>
                        3. เตรียมไฟฉายหรือนกหวีด<br>
                        4. ประหยัดแบตเตอรี่มือถือ<br>
                        5. หากอันตรายถึงชีวิต <strong>โทร 1784</strong>
                    </div>
                </div>
                <button class="btn btn-outline" style="margin-top: var(--spacing-lg);" onclick="closeLIFF()">
                    ❌ ปิดหน้าต่าง
                </button>
            </div>
        </div>

    </div>

    <script>
        // ====== STATE ======
        let currentStep = 1;
        let formData = {
            latitude: null,
            longitude: null,
            severity: null,
            severityLabel: '',
            victimCount: 1,
            vulnerableGroups: [],
            details: '',
            photo: null,
            userId: null
        };

        // ====== LIFF INIT ======
        async function initLIFF() {
            try {
                await liff.init({ liffId: getLiffId() });
                if (liff.isLoggedIn()) {
                    const profile = await liff.getProfile();
                    formData.userId = profile.userId;
                }
                // Auto get GPS
                getGPS();
            } catch (err) {
                console.error('LIFF init failed:', err);
                document.getElementById('gpsStatus').className = 'gps-status error';
                document.getElementById('gpsStatus').innerHTML = '⚠️ ไม่สามารถเชื่อมต่อ LINE ได้ กรุณาเปิดจากแอป LINE';
            }
        }

        function getLiffId() {
            // Try to get from URL params
            const params = new URLSearchParams(window.location.search);
            return params.get('liffId') || '';
        }

        // ====== GPS ======
        function getGPS() {
            const statusEl = document.getElementById('gpsStatus');
            const btnGPS = document.getElementById('btnGetGPS');
            
            statusEl.className = 'gps-status loading';
            statusEl.innerHTML = '<div class="spinner" style="display:inline-block;width:24px;height:24px;margin-right:8px;"></div> กำลังระบุตำแหน่ง...';
            btnGPS.classList.add('hidden');

            if (!navigator.geolocation) {
                statusEl.className = 'gps-status error';
                statusEl.innerHTML = '⚠️ เบราว์เซอร์ไม่รองรับ GPS';
                btnGPS.classList.remove('hidden');
                return;
            }

            navigator.geolocation.getCurrentPosition(
                (position) => {
                    formData.latitude = position.coords.latitude.toFixed(6);
                    formData.longitude = position.coords.longitude.toFixed(6);
                    
                    document.getElementById('latValue').textContent = formData.latitude;
                    document.getElementById('lonValue').textContent = formData.longitude;
                    
                    // Try to get address (reverse geocoding)
                    getAddress(formData.latitude, formData.longitude);
                    
                    document.getElementById('gpsResult').classList.remove('hidden');
                    statusEl.className = 'gps-status success';
                    statusEl.innerHTML = '✅ ระบุตำแหน่งสำเร็จ';
                    document.getElementById('btnNext1').classList.remove('hidden');
                },
                (error) => {
                    let msg = 'ไม่สามารถดึงพิกัดได้';
                    switch(error.code) {
                        case error.PERMISSION_DENIED: msg = '⛔ กรุณาอนุญาตให้เข้าถึงตำแหน่ง'; break;
                        case error.POSITION_UNAVAILABLE: msg = '📡 ไม่พบสัญญาณ GPS'; break;
                        case error.TIMEOUT: msg = '⏱️ หมดเวลารอ GPS'; break;
                    }
                    statusEl.className = 'gps-status error';
                    statusEl.innerHTML = '⚠️ ' + msg;
                    btnGPS.classList.remove('hidden');
                    btnGPS.textContent = '📍 ลองใหม่';
                },
                { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
            );
        }

        async function getAddress(lat, lon) {
            try {
                const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`);
                const data = await res.json();
                const addr = data.address;
                const display = addr ? 
                    `${addr.subdistrict || ''} ${addr.district || ''} ${addr.city || addr.province || ''}` : 
                    'ไม่สามารถระบุที่อยู่ได้';
                document.getElementById('addressValue').textContent = display;
                formData.address = display;
            } catch (e) {
                document.getElementById('addressValue').textContent = 'ไม่สามารถระบุที่อยู่ได้';
            }
        }

        // ====== NAVIGATION ======
        function goToStep(step) {
            // Hide all steps
            for (let i = 1; i <= 5; i++) {
                document.getElementById('step' + i).classList.add('hidden');
            }
            
            // Show target step
            document.getElementById('step' + step).classList.remove('hidden');
            document.getElementById('step' + step).classList.add('fade-in');
            
            // Update progress dots
            for (let i = 1; i <= 5; i++) {
                const dot = document.getElementById('step' + i + '-dot');
                const line = document.getElementById('line' + i);
                
                dot.classList.remove('active', 'completed');
                if (line) line.classList.remove('completed');
                
                if (i < step) {
                    dot.classList.add('completed');
                    dot.textContent = '✓';
                    if (line) line.classList.add('completed');
                } else if (i === step) {
                    dot.classList.add('active');
                    dot.textContent = i;
                } else {
                    dot.textContent = i;
                }
            }
            
            currentStep = step;
            
            // If going to summary, update it
            if (step === 5) {
                updateSummary();
            }
            
            window.scrollTo(0, 0);
        }

        // ====== SEVERITY SELECTION ======
        function selectSeverity(level, label) {
            formData.severity = level;
            formData.severityLabel = label;
            
            document.querySelectorAll('.severity-btn').forEach(btn => btn.classList.remove('selected'));
            document.querySelector('.severity-btn.' + level).classList.add('selected');
            
            setTimeout(() => goToStep(3), 300);
        }

        // ====== VICTIM COUNT ======
        function changeCount(delta) {
            formData.victimCount = Math.max(1, formData.victimCount + delta);
            document.getElementById('victimCount').textContent = formData.victimCount;
        }

        // ====== VULNERABLE GROUPS ======
        function toggleGroup(id, label) {
            const btn = document.getElementById('group-' + id);
            const idx = formData.vulnerableGroups.indexOf(label);
            
            if (idx > -1) {
                formData.vulnerableGroups.splice(idx, 1);
                btn.classList.remove('selected');
            } else {
                formData.vulnerableGroups.push(label);
                btn.classList.add('selected');
            }
        }

        // ====== PHOTO ======
        function handlePhoto(input) {
            if (input.files && input.files[0]) {
                formData.photo = input.files[0];
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('photoPreview');
                    preview.src = e.target.result;
                    preview.classList.remove('hidden');
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        // ====== SUMMARY ======
        function updateSummary() {
            formData.details = document.getElementById('detailsInput').value || '-';
            
            document.getElementById('sumGPS').textContent = 
                formData.latitude ? `${formData.latitude}, ${formData.longitude}` : 'ไม่ระบุ';
            document.getElementById('sumSeverity').textContent = formData.severityLabel || 'ไม่ระบุ';
            document.getElementById('sumCount').textContent = formData.victimCount + ' คน';
            document.getElementById('sumGroups').textContent = 
                formData.vulnerableGroups.length > 0 ? formData.vulnerableGroups.join(', ') : 'ไม่มี';
            document.getElementById('sumDetails').textContent = formData.details;
        }

        // ====== SUBMIT ======
        async function submitSOS() {
            const btn = document.getElementById('btnSubmit');
            btn.disabled = true;
            btn.innerHTML = '<div class="spinner" style="width:28px;height:28px;border-width:3px;display:inline-block;margin-right:8px;"></div> กำลังส่งข้อมูล...';
            
            // Priority calculation
            let priority = 'NORMAL';
            if (formData.severity === 'critical') priority = 'CRITICAL';
            else if (formData.severity === 'high') priority = 'HIGH';
            else if (formData.vulnerableGroups.some(g => ['เด็กเล็ก', 'ผู้สูงอายุ', 'ผู้ป่วยติดเตียง'].includes(g))) 
                priority = 'HIGH';
            
            const payload = {
                user_id: formData.userId || 'unknown',
                latitude: formData.latitude,
                longitude: formData.longitude,
                water_level_status: formData.severityLabel,
                victim_count: formData.victimCount,
                vulnerable_groups: formData.vulnerableGroups.join(', '),
                group_types: 'ผู้ประสบภัย',
                urgency_level: formData.severity === 'critical' ? 'วิกฤต' : 
                              formData.severity === 'high' ? 'สูง' : 
                              formData.severity === 'medium' ? 'ปานกลาง' : 'ต่ำ',
                details: formData.details,
                priority: priority,
                photo_url: formData.photo ? 'uploaded' : '-'
            };
            
            try {
                const response = await fetch('/api/sos/submit', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                
                const result = await response.json();
                
                if (result.success) {
                    document.getElementById('caseId').textContent = result.case_id;
                    document.getElementById('step5').classList.add('hidden');
                    document.getElementById('successScreen').classList.remove('hidden');
                    document.getElementById('successScreen').classList.add('fade-in');
                    
                    // Send SMS notification if needed
                    notifyEmergencyContacts(result.case_id);
                } else {
                    throw new Error(result.error || 'Unknown error');
                }
            } catch (error) {
                btn.disabled = false;
                btn.innerHTML = '🚨 ลองส่งใหม่';
                alert('❌ ส่งข้อมูลไม่สำเร็จ: ' + error.message + '\n\nข้อมูลถูกบันทึกไว้ในเครื่องแล้ว กรุณาลองใหม่');
            }
        }

        // ====== NOTIFICATION ======
        async function notifyEmergencyContacts(caseId) {
            // This would integrate with SMS gateway
            console.log('Emergency case:', caseId);
        }

        // ====== CLOSE LIFF ======
        function closeLIFF() {
            if (liff.isInClient()) {
                liff.closeWindow();
            } else {
                window.close();
            }
        }

        // ====== INIT ======
        document.addEventListener('DOMContentLoaded', initLIFF);
    </script>
</body>
</html>
"""


# =============================================================================
# STANDALONE FLASK ROUTE (for testing without app.py)
# =============================================================================

if __name__ == "__main__":
    from flask import Flask, render_template_string
    app = Flask(__name__)
    
    @app.route("/liff/sos")
    def sos_page():
        return render_template_string(SOS_LIFF_HTML)
    
    print("=" * 60)
    print("FLOODCARE AI - SOS LIFF Test Server")
    print("=" * 60)
    print("Open: http://localhost:5001/liff/sos")
    print("=" * 60)
    
    app.run(host="0.0.0.0", port=5001, debug=True)
