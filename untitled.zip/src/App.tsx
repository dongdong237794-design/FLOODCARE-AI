/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from "react";
import Sidebar from "./components/Sidebar";
import OverviewTab from "./components/OverviewTab";
import WaterTab from "./components/WaterTab";
import SOSTab from "./components/SOSTab";
import NeedsTab from "./components/NeedsTab";
import ProfilesTab from "./components/ProfilesTab";
import AiChatTab from "./components/AiChatTab";
import MockLineSimulator from "./components/MockLineSimulator";
import { RegisteredUser, SOSRequest, UserNeed, WaterStation } from "./types";

export default function App() {
  const [activeTab, setActiveTab] = useState("overview");

  // State caches
  const [stations, setStations] = useState<WaterStation[]>([]);
  const [sosRequests, setSosRequests] = useState<SOSRequest[]>([]);
  const [userNeeds, setUserNeeds] = useState<UserNeed[]>([]);
  const [registeredUsers, setRegisteredUsers] = useState<RegisteredUser[]>([]);

  // Loader and trigger flags
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [toastMessage, setToastMessage] = useState("");

  // Auto-clear toast helper
  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(""), 4000);
  };

  // Fetch initial backend configurations
  const pullAllData = async () => {
    try {
      const [resStations, resSOS, resNeeds, resProfiles] = await Promise.all([
        fetch("/api/thaiwater/stations"),
        fetch("/api/sos/requests"),
        fetch("/api/needs"),
        fetch("/api/profiles")
      ]);

      const stationsData = await resStations.json();
      const sosData = await resSOS.json();
      const needsData = await resNeeds.json();
      const profilesData = await resProfiles.json();

      setStations(stationsData);
      setSosRequests(sosData);
      setUserNeeds(needsData);
      setRegisteredUsers(profilesData);
    } catch (err) {
      console.error("Error drawing dashboard data:", err);
      setErrorMessage("เกิดข้อผิดพลาดในการดึงข้อมูลจากระบบหลัก โปรดดูคอนโซลระบบเพื่อแก้ไข");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    pullAllData();
    // Poll updates every 15 seconds to keep the dashboard lively
    const interval = setInterval(pullAllData, 15000);
    return () => clearInterval(interval);
  }, []);

  // Sync ThaiWater live API trigger
  const syncWaterData = async () => {
    setSyncing(true);
    setErrorMessage("");
    try {
      const response = await fetch("/api/thaiwater/sync", {
        method: "POST"
      });
      const result = await response.json();
      if (result.success) {
        setLastSyncTime(result.lastSyncTime);
        triggerToast(`🎉 ผสานพิกัดระดับน้ำเรียลไทม์สำเร็จ! ประมวลผลจำนวน ${result.count} สถานีจริง`);
        // Refresh stations cache
        const resSt = await fetch("/api/thaiwater/stations");
        const freshList = await resSt.json();
        setStations(freshList);
      } else {
        throw new Error(result.message || "Unknown error during synchronization");
      }
    } catch (err: any) {
      console.error("Manual sync failed:", err);
      setErrorMessage(`ไม่สามารถสื่อสารดึงข้อมูล ThaiWater: ${err.message || "หมดเวลาการสนทนาขั้วสาย"}`);
      triggerToast("❌ ลิมิตการดึงพิกัด ขัดข้องชั่วคราว");
    } finally {
      setSyncing(false);
    }
  };

  // Profile creation callback (via LINE simulation)
  const handleRegisterUser = async (firstName: string, lastName: string, phone: string) => {
    try {
      const response = await fetch("/api/profiles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ firstName, lastName, phone })
      });
      const data = await response.json();
      setRegisteredUsers((prev) => [data, ...prev]);
      triggerToast(`👤 ลงทะเบียนสิทธิ์ของ ${firstName} เรียบร้อยแล้ว`);
    } catch (err) {
      console.error("Error creating profile:", err);
    }
  };

  // Submit SOS request (via LINE simulation)
  const handleSubmitSOS = async (sosPayload: any) => {
    try {
      const response = await fetch("/api/sos/requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(sosPayload)
      });
      const data = await response.json();
      setSosRequests((prev) => [data, ...prev]);
      triggerToast(`🚨 บันทึกเคสฉุกเฉินกรณีด่วนของ ${sosPayload.userName} สำเร็จ`);
    } catch (err) {
      console.error("Error saving SOS:", err);
    }
  };

  // Submit User Need request (via LINE simulation)
  const handleSubmitNeed = async (needPayload: any) => {
    try {
      const response = await fetch("/api/needs", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(needPayload)
      });
      const data = await response.json();
      setUserNeeds((prev) => [data, ...prev]);
      triggerToast(`📦 บันทึกความต้องการถุงยังชีพสำเร็จ`);
    } catch (err) {
      console.error("Error saving needs:", err);
    }
  };

  // Accept/Dispatch SOS case
  const handleAcceptSOS = async (id: string, responderName: string, notes: string) => {
    try {
      const response = await fetch(`/api/sos/requests/${id}/accept`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ responderName, responderNotes: notes })
      });
      const updated = await response.json();
      setSosRequests((prev) => prev.map((item) => (item.requestId === id ? updated : item)));
      triggerToast(`🔵 มอบกำลังสั่งการชุดปฏิบัติการ ${responderName} สำเร็จ`);
    } catch (err) {
      console.error("Accept error:", err);
    }
  };

  // Resolve SOS Case
  const handleResolveSOS = async (id: string, notes: string) => {
    try {
      const response = await fetch(`/api/sos/requests/${id}/resolve`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notes })
      });
      const updated = await response.json();
      setSosRequests((prev) => prev.map((item) => (item.requestId === id ? updated : item)));
      triggerToast(`🟢 อพยพภัยพิบัติและปิดรายงานสำเร็จลุล่วงด้วยดี`);
    } catch (err) {
      console.error("Resolve error:", err);
    }
  };

  // Complete User Need delivery
  const handleCompleteNeed = async (id: string) => {
    try {
      const response = await fetch(`/api/needs/${id}/complete`, {
        method: "POST"
      });
      const updated = await response.json();
      setUserNeeds((prev) => prev.map((item) => (item.id === id ? updated : item)));
      triggerToast(`✅ ส่งของแจกจ่ายถุงบรรเทาสำเร็จ ปิดประเด็นพิมม์รายงาน`);
    } catch (err) {
      console.error("Complete need error:", err);
    }
  };

  // Render correct tab view panel
  const renderTabContent = () => {
    switch (activeTab) {
      case "overview":
        return (
          <OverviewTab
            sosRequests={sosRequests}
            userNeeds={userNeeds}
            registeredUsersCount={registeredUsers.length}
            stations={stations}
            setActiveTab={setActiveTab}
            syncWaterData={syncWaterData}
            lastSyncTime={lastSyncTime}
          />
        );
      case "water":
        return (
          <WaterTab
            stations={stations}
            syncWaterData={syncWaterData}
            syncing={syncing}
            lastSyncTime={lastSyncTime}
          />
        );
      case "sos":
        return (
          <SOSTab
            sosRequests={sosRequests}
            onAcceptCase={handleAcceptSOS}
            onResolveCase={handleResolveSOS}
          />
        );
      case "needs":
        return <NeedsTab userNeeds={userNeeds} onCompleteNeed={handleCompleteNeed} />;
      case "profiles":
        return <ProfilesTab users={registeredUsers} />;
      case "aichat":
        return <AiChatTab />;
      case "line_simulator":
        return (
          <MockLineSimulator
            onRegisterUser={handleRegisterUser}
            onSubmitSOS={handleSubmitSOS}
            onSubmitNeed={handleSubmitNeed}
          />
        );
      default:
        return <div>ระบุข้อผิดพลาดในการโหลดแท็บแผงควบคุม</div>;
    }
  };

  const openSosCount = sosRequests.filter((request) => request.status === "OPEN").length;
  const pendingNeedsCount = userNeeds.filter((need) => need.status === "PENDING").length;

  return (
    <div className="flex bg-slate-50 min-h-screen text-slate-800 antialiased font-sans">
      {/* Sidebar navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        openSosCount={openSosCount}
        pendingNeedsCount={pendingNeedsCount}
      />

      {/* Main Content Workspace viewport */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Banner Alert Toast / Errors if exists */}
        <div className="shrink-0">
          {errorMessage && (
            <div className="bg-red-500 text-white text-xs text-center font-semibold py-2 px-4 shadow-sm flex items-center justify-between gap-4">
              <span>⚠️ มีคลื่นขัดข้อในการเชื่อมต่อ: {errorMessage}</span>
              <button onClick={() => setErrorMessage("")} className="font-bold hover:underline">
                [ปิดฟลอป]
              </button>
            </div>
          )}

          {toastMessage && (
            <div className="bg-blue-600 text-white text-xs font-bold text-center py-2.5 px-4 shadow-md transition-all duration-300">
              {toastMessage}
            </div>
          )}
        </div>

        {/* Dynamic Panel Scroll-Frame container */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8">
          {loading ? (
            <div className="h-full flex flex-col items-center justify-center space-y-4">
              <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-sm text-slate-500 font-mono">
                กำลังสตรีมพอร์ตเชื่อมและจัดสำรวจระบบพิกัด...
              </p>
            </div>
          ) : (
            renderTabContent()
          )}
        </div>
      </main>
    </div>
  );
}
