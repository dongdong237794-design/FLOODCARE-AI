/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface RegisteredUser {
  userId: string;
  firstName: string;
  lastName: string;
  phone: string;
  registerDate: string;
  status: "ACTIVE" | "INACTIVE";
}

export type UrgencyLevel = "วิกฤต" | "สูง" | "ปานกลาง" | "ต่ำ" | "ขาดแคลนยา" | string;

export interface SOSRequest {
  requestId: string;
  userId: string;
  userName: string;
  phone: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  groupTypes: string[];
  urgencyLevel: UrgencyLevel;
  photoUrl?: string;
  note: string;
  priority: "CRITICAL" | "HIGH" | "NORMAL";
  status: "OPEN" | "IN_PROGRESS" | "RESOLVED";
  responderName?: string;
  responderNotes?: string;
  acceptedAt?: string;
  resolvedAt?: string;
}

export interface UserNeed {
  id: string;
  userId: string;
  userName: string;
  phone: string;
  timestamp: string;
  latitude: number;
  longitude: number;
  categories: string[];
  details: string;
  urgency: "ด่วนมาก (หมดแล้ว)" | "ปานกลาง (รอได้ 24 ชม.)" | "ไม่ด่วน (แจ้งไว้ล่วงหน้า)" | string;
  status: "PENDING" | "COMPLETED";
}

export interface WaterStation {
  stationCode: string;
  name: string;
  river: string;
  location: string; // Province
  lat: number;
  lon: number;
  waterLevel: number | string; // m MSL
  bankLevel: number | string;  // m MSL
  situation: "ปกติ" | "เฝ้าระวัง" | "วิกฤต" | string;
  trend: "เพิ่มขึ้น" | "ลดลง" | "คงที่" | string;
  time: string;
}

export interface AIChatMessage {
  id: string;
  sender: "user" | "ai";
  text: string;
  timestamp: string;
}
