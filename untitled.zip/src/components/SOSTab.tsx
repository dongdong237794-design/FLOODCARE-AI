/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { SOSRequest, UrgencyLevel } from "../types.js";
import {
  AlertTriangle,
  Ship,
  CheckCircle2,
  Phone,
  Clock,
  MapPin,
  FileText,
  BadgeAlert,
  Search,
  Filter
} from "lucide-react";

interface SOSTabProps {
  sosRequests: SOSRequest[];
  onAcceptCase: (id: string, responderName: string, notes: string) => void;
  onResolveCase: (id: string, notes: string) => void;
}

export default function SOSTab({
  sosRequests,
  onAcceptCase,
  onResolveCase
}: SOSTabProps) {
  const [selectedStatus, setSelectedStatus] = useState<string>("all");
  const [selectedPriority, setSelectedPriority] = useState<string>("all");
  const [searchWord, setSearchWord] = useState<string>("");

  // Handler state for Accept Modal
  const [activeAcceptId, setActiveAcceptId] = useState<string | null>(null);
  const [dispName, setDispName] = useState("");
  const [dispNotes, setDispNotes] = useState("");

  // Handler state for Resolve modal
  const [activeResolveId, setActiveResolveId] = useState<string | null>(null);
  const [resolveNotes, setResolveNotes] = useState("");

  const filteredRequests = sosRequests.filter((r) => {
    const matchStatus = selectedStatus === "all" || r.status === selectedStatus;
    const matchPriority = selectedPriority === "all" || r.priority === selectedPriority;
    const matchQuery =
      r.userName.toLowerCase().includes(searchWord.toLowerCase()) ||
      r.phone.includes(searchWord) ||
      (r.note && r.note.toLowerCase().includes(searchWord.toLowerCase())) ||
      r.groupTypes.join(" ").toLowerCase().includes(searchWord.toLowerCase());

    return matchStatus && matchPriority && matchQuery;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-gray-100">
        <h2 className="text-2xl font-sans font-bold text-slate-800 tracking-tight flex items-center gap-2.5">
          <BadgeAlert className="w-6.5 h-6.5 text-red-500 animate-pulse" />
          ศูนย์รับแจ้งชีวิตฉุกเฉินและกระจายกำลังสั่งการ (LINE SOS Feed)
        </h2>
        <p className="text-sm text-slate-500 mt-1">
          คัดกรองจัดลำดับความเร่งด่วนอัตโนมัติ (Critical Priority) เพื่อคุ้มครองกลุ่มเปราะบางเป็นอันดับแรก
        </p>
      </div>

      {/* Live Feed Filters */}
      <div className="bg-white border border-gray-150 rounded-xl p-4 flex flex-col md:flex-row gap-4 items-center">
        {/* Search */}
        <div className="relative w-full md:flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="ค้นหาชื่อผู้แจ้ง, เบอร์โทร, หรืออาการความต้องการ..."
            value={searchWord}
            onChange={(e) => setSearchWord(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm bg-gray-50 outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white transition"
          />
        </div>

        {/* Option Group */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <Filter className="w-4 h-4 text-slate-400" />
            <span className="text-xs text-slate-500 whitespace-nowrap">สถานะ:</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs bg-white text-slate-700 outline-none"
            >
              <option value="all">ทั้งหมด</option>
              <option value="OPEN">🔴 ค้างรับเรื่อง (OPEN)</option>
              <option value="IN_PROGRESS">🔵 กำลังเข้าชาร์จช่วยเหลือ (IN PROGRESS)</option>
              <option value="RESOLVED">🟢 กู้ชีพสำเร็จราบรื่น (RESOLVED)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <span className="text-xs text-slate-500 whitespace-nowrap">ความเร่งด่วน:</span>
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs bg-white text-slate-700 outline-none"
            >
              <option value="all">ทั้งหมด</option>
              <option value="CRITICAL">🚨 วิกฤตสูงสุด (CRITICAL)</option>
              <option value="HIGH">⚡ สูง (HIGH)</option>
              <option value="NORMAL">ปกติ (NORMAL)</option>
            </select>
          </div>
        </div>
      </div>

      {/* SOS List Rendering */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredRequests.length === 0 ? (
          <div className="col-span-full bg-white border border-gray-200 rounded-xl p-12 text-center text-slate-400">
            📭 ไม่พบเคสแจ้งภัยที่อยู่ภายใต้เงื่อนไขการกรองของคุณ
          </div>
        ) : (
          filteredRequests.map((sos) => {
            return (
              <div
                key={sos.requestId}
                className={`bg-white border rounded-xl overflow-hidden shadow-xs transition duration-150 flex flex-col justify-between ${
                  sos.priority === "CRITICAL"
                    ? "border-red-200 hover:border-red-300 ring-l-4 ring-red-500"
                    : sos.priority === "HIGH"
                    ? "border-amber-200 hover:border-amber-300 ring-l-4 ring-amber-500"
                    : "border-gray-200 hover:border-slate-300 ring-l-4 ring-slate-400"
                }`}
              >
                {/* ID Header */}
                <div className="bg-slate-50 px-4 py-3 border-b border-gray-150 flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-600">
                    {sos.requestId}
                  </span>
                  <div className="flex items-center gap-2">
                    {/* Priority Tag */}
                    <span
                      className={`text-[9px] font-sans font-bold px-2 py-0.5 rounded-full uppercase ${
                        sos.priority === "CRITICAL"
                          ? "bg-red-500 text-white"
                          : sos.priority === "HIGH"
                          ? "bg-amber-500 text-slate-900"
                          : "bg-slate-200 text-slate-800"
                      }`}
                    >
                      {sos.priority}
                    </span>

                    {/* Status Badge */}
                    <span
                      className={`text-[9px] font-sans font-bold px-2 py-0.5 rounded-full uppercase ${
                        sos.status === "OPEN"
                          ? "bg-red-100 text-red-700 animate-pulse border border-red-200"
                          : sos.status === "IN_PROGRESS"
                          ? "bg-blue-100 text-blue-700 border border-blue-200"
                          : "bg-emerald-100 text-emerald-700 border border-emerald-200"
                      }`}
                    >
                      {sos.status}
                    </span>
                  </div>
                </div>

                {/* Content */}
                <div className="p-4 space-y-3 flex-1">
                  {/* Basic user info */}
                  <div className="flex items-center justify-between text-slate-800">
                    <span className="font-bold text-sm text-slate-950">{sos.userName}</span>
                    <a
                      href={`tel:${sos.phone}`}
                      className="text-xs text-blue-600 font-mono hover:underline flex items-center gap-1 font-bold"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      {sos.phone}
                    </a>
                  </div>

                  {/* Lat Long Coordinates */}
                  <div className="text-xs text-slate-500 flex items-center gap-1.5 font-mono">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>
                      พิกัด GPS: {sos.latitude.toFixed(5)}, {sos.longitude.toFixed(5)}
                    </span>
                    <a
                      href={`https://maps.google.com/?q=${sos.latitude},${sos.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] text-blue-500 font-bold hover:underline"
                    >
                      [ดูแผนที่และนำทาง]
                    </a>
                  </div>

                  {/* Group Members Tag */}
                  <div className="flex flex-wrap gap-1">
                    {sos.groupTypes.map((gp, i) => (
                      <span key={i} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-medium">
                        👥 {gp}
                      </span>
                    ))}
                  </div>

                  {/* Urgency Level Message */}
                  <div className="bg-slate-50 p-2.5 rounded-lg border border-gray-150 text-xs">
                    <div className="font-semibold text-slate-500">ระดับน้ำ / สถานการณ์แวดล้อม:</div>
                    <div className="text-slate-800 font-medium mt-0.5">{sos.urgencyLevel}</div>
                  </div>

                  {/* Text Description */}
                  {sos.note && (
                    <p className="text-xs text-slate-600 bg-amber-50/50 p-2.5 border border-amber-100 rounded-lg italic">
                      " {sos.note} "
                    </p>
                  )}

                  {/* Photo evidence if exists */}
                  {sos.photoUrl && (
                    <div className="relative mt-2 rounded-lg overflow-hidden border border-gray-200">
                      <img src={sos.photoUrl} alt="หลักฐาน" className="w-full h-32 object-cover" />
                      <div className="absolute top-1 right-1 bg-black/60 text-[10px] text-white px-2 py-0.5 rounded">
                        หลักฐานกล้อง
                      </div>
                    </div>
                  )}

                  {/* Dispatcher Actions Logs */}
                  {(sos.responderName || sos.responderNotes) && (
                    <div className="border-t border-gray-100 pt-3 mt-3 text-xs space-y-1 bg-slate-50/70 p-2.5 rounded-lg border border-gray-150">
                      <div className="font-semibold text-slate-700 flex items-center gap-1">
                        <Ship className="w-3.5 h-3.5 text-blue-600" />
                        หน่วยงานเข้ากู้ชีพ: <span className="text-blue-700">{sos.responderName}</span>
                      </div>
                      <p className="text-slate-500 italic">" {sos.responderNotes} "</p>
                      {sos.acceptedAt && (
                        <div className="text-[10px] text-slate-400 font-mono">
                          เวลาประสานงาน: {sos.acceptedAt}
                        </div>
                      )}
                      {sos.resolvedAt && (
                        <div className="text-[10px] text-emerald-600 font-mono font-bold mt-1">
                          ช่วยเหลืออพยพสำเร็จ: {sos.resolvedAt}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Card Action footer button */}
                <div className="p-4 pt-0 border-t border-gray-50 flex items-center gap-2 mt-auto">
                  {sos.status === "OPEN" && (
                    <button
                      id={`accept-btn-${sos.requestId}`}
                      onClick={() => {
                        setActiveAcceptId(sos.requestId);
                        setDispName("กู้ชีพกู้ภัยพระราชทาน ร่วมกตัญญู");
                        setDispNotes("เตรียมเข้าพื้นที่พร้อมเรือเจ็ตสกีขนาดกลาง");
                      }}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-sans text-xs font-bold py-2 rounded-lg text-center flex items-center justify-center gap-1 hover:shadow-xs transition duration-150"
                    >
                      <Ship className="w-3.5 h-3.5" />
                      ประสานงานรุดกู้ภัย
                    </button>
                  )}

                  {sos.status === "IN_PROGRESS" && (
                    <button
                      id={`resolve-btn-${sos.requestId}`}
                      onClick={() => {
                        setActiveResolveId(sos.requestId);
                        setResolveNotes("อพยพผู้ประสบภัยและสัตว์เลี้ยงไปยังค่ายพักพิงพบลำน้ำปลอดภัยเรียบร้อย");
                      }}
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-sans text-xs font-bold py-2 rounded-lg text-center flex items-center justify-center gap-1 hover:shadow-xs transition duration-150"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      ยืนยันตัวตนสำเร็จ (RESOLVE CASE)
                    </button>
                  )}

                  {sos.status === "RESOLVED" && (
                    <div className="w-full text-center text-xs font-bold text-emerald-600 bg-emerald-50 py-2 border border-emerald-200 rounded-lg flex items-center justify-center gap-1">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      คุ้มกัน ปลอดภัยเรียบร้อยแล้ว
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Accept Case Overlay Modal Form */}
      {activeAcceptId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg border border-gray-200 w-full max-w-md p-6 space-y-4">
            <h3 className="font-sans font-bold text-slate-900 text-lg">ระบุรายละเอียดจัดตั้งทีมกู้ชีพ</h3>
            
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-slate-500 uppercase">ชื่อหน่วยงานปฏิบัติการ:</label>
                <input
                  type="text"
                  value={dispName}
                  onChange={(e) => setDispName(e.target.value)}
                  className="w-full mt-1 p-2 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:bg-white focus:border-blue-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-500 uppercase">แผนงานหรือหมายเหตุประสานกู้ชีพ:</label>
                <textarea
                  value={dispNotes}
                  onChange={(e) => setDispNotes(e.target.value)}
                  className="w-full mt-1 p-2 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:bg-white focus:border-blue-500 outline-none h-20"
                ></textarea>
              </div>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => {
                  onAcceptCase(activeAcceptId, dispName, dispNotes);
                  setActiveAcceptId(null);
                }}
                className="flex-1 bg-blue-600 text-white font-sans text-xs font-bold py-2 rounded-lg"
              >
                ยืนยันและอัปเดต LINE ผู้ใช้อัตโนมัติ
              </button>
              <button
                onClick={() => setActiveAcceptId(null)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-sans text-xs font-semibold px-4 py-2 rounded-lg"
              >
                ยกเลิก
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Resolve Case Overlay Modal Form */}
      {activeResolveId && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-lg border border-gray-200 w-full max-w-md p-6 space-y-4">
            <h3 className="font-sans font-bold text-slate-900 text-lg text-emerald-800">ส่งรายงานกู้ภัยปิดเคสสำเร็จ</h3>
            
            <div>
              <label className="block text-xs font-medium text-slate-500 uppercase">สรุปความปลอดภัยและการรักษาพยาบาลหลัก:</label>
              <textarea
                value={resolveNotes}
                onChange={(e) => setResolveNotes(e.target.value)}
                placeholder="ระบุข้อความอธิบายการส่งกลับศูนย์อพยพหลัก"
                className="w-full mt-1 p-2 border border-gray-200 rounded-lg text-sm bg-gray-50 focus:bg-white outline-none h-24"
              ></textarea>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                onClick={() => {
                  onResolveCase(activeResolveId, resolveNotes);
                  setActiveResolveId(null);
                }}
                className="flex-1 bg-emerald-600 text-white font-sans text-xs font-bold py-2 rounded-lg"
              >
                ส่งกลับรายงาน อพยพสำเร็จ!
              </button>
              <button
                onClick={() => setActiveResolveId(null)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-sans text-xs font-semibold px-4 py-2 rounded-lg"
              >
                ยกเลิก
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
