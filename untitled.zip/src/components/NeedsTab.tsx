/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { UserNeed } from "../types.js";
import {
  Package,
  ShoppingBag,
  CheckCircle2,
  Phone,
  Clock,
  MapPin,
  ClipboardList,
  Tags,
  AlertCircle
} from "lucide-react";

interface NeedsTabProps {
  userNeeds: UserNeed[];
  onCompleteNeed: (id: string) => void;
}

export default function NeedsTab({ userNeeds, onCompleteNeed }: NeedsTabProps) {
  const [filterCat, setFilterCat] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");

  const filteredNeeds = userNeeds.filter((n) => {
    const matchCat = filterCat === "all" || n.categories.includes(filterCat);
    const matchStatus = filterStatus === "all" || n.status === filterStatus;
    return matchCat && matchStatus;
  });

  // Calculate master packing summaries for volunteers
  const activePendingNeeds = userNeeds.filter((n) => n.status === "PENDING");
  
  const categoryCounts: Record<string, number> = {};
  activePendingNeeds.forEach((need) => {
    need.categories.forEach((cat) => {
      categoryCounts[cat] = (categoryCounts[cat] || 0) + 1;
    });
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-sans font-bold text-slate-800 tracking-tight flex items-center gap-2">
            <Package className="w-6 h-6 text-amber-500" />
            รายงานสิ่งของขาดแคลนและเวชภัณฑ์กู้ชีพ
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            ระบุพิกัดความต้องการเสบียงจากประชาชนและโรงครัวเพื่อจัดสรรรถ/เรือจัดของแจกจ่าย
          </p>
        </div>
      </div>

      {/* Grid: Split packing summary & list */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left column: volunteer packing bag generator */}
        <div className="bg-slate-900 text-slate-100 p-5 rounded-2xl border border-slate-800 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
              <ClipboardList className="w-5 h-5 text-amber-500" />
              <h3 className="font-sans font-bold text-white text-base">ใบสั่งจัดเสบียงรวม (สำหรับอาสาสมัคร)</h3>
            </div>
            
            <p className="text-xs text-slate-400 mt-2.5">
              💡 ผลรวมรายการสิ่งของจากผู้เดือดร้อนทั้งหมดที่ยังไม่ได้ขนส่งสำเร็จ จัดขึ้นเรือกู้ภัย:
            </p>

            <div className="mt-4 space-y-3.5 flex-1">
              {Object.keys(categoryCounts).length === 0 ? (
                <div className="text-center text-slate-500 text-xs py-8">
                  ไม่มีใบเสบียงคงค้าง อาสาสมัครสามารถพักเตรียมตู้ยาได้เลยครับ!
                </div>
              ) : (
                Object.entries(categoryCounts).map(([cat, count], idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs bg-slate-950 p-3 rounded-lg border border-slate-800">
                    <div className="flex items-center gap-2">
                      <ShoppingBag className="w-4 h-4 text-amber-400" />
                      <span className="font-bold text-slate-200">{cat}</span>
                    </div>
                    <span className="bg-amber-500 text-slate-950 text-xs px-2.5 py-0.5 rounded-full font-mono font-bold">
                      {count} ครัวเรือน
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-850">
            <div className="text-[10px] text-slate-500 font-mono tracking-widest text-center uppercase">
              จัดเสร็จแล้วให้นำขึ้นเรือตรวจสภท. ประสานงานลำน้ำ
            </div>
          </div>
        </div>

        {/* Right column: list of item requests */}
        <div className="lg:col-span-2 space-y-4">
          {/* Filters */}
          <div className="bg-white border border-gray-150 p-4 rounded-xl flex flex-wrap gap-4 items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">หมวดหมู่เสบียง:</span>
              <select
                value={filterCat}
                onChange={(e) => setFilterCat(e.target.value)}
                className="px-2 py-1 border border-gray-200 rounded-lg text-xs bg-slate-50 text-slate-700 outline-none"
              >
                <option value="all">ทั้งหมด</option>
                <option value="🍱 อาหาร/น้ำดื่ม">🍱 อาหาร/น้ำดื่ม</option>
                <option value="ยารักษาโรค/เวชภัณฑ์">💊 ยารักษาโรค/เวชภัณฑ์</option>
                <option value="👶 นมผง/แพมเพิสเด็ก">👶 นมผง/แพมเพิสเด็ก</option>
                <option value="🧼 ของใช้ส่วนตัว/ทิชชู่">🧼 ของใช้ส่วนตัว/ทิชชู่</option>
                <option value="🔦 ไฟฉาย/แบตเตอรี่สำรอง">🔦 ไฟฉาย/แบตเตอรี่สำรอง</option>
                <option value="📝 อื่นๆ">📝 อื่นๆ</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">สถานะกู้ชีพเรือเสบียง:</span>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-2 py-1 border border-gray-200 rounded-lg text-xs bg-slate-50 text-slate-700 outline-none"
              >
                <option value="all">ทั้งหมด</option>
                <option value="PENDING">📦 ค้างส่งมอบ (PENDING)</option>
                <option value="COMPLETED">✅ ส่งของสำเร็จ (COMPLETED)</option>
              </select>
            </div>
          </div>

          {/* List display */}
          <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
            {filteredNeeds.length === 0 ? (
              <div className="bg-white border border-gray-200 rounded-xl p-12 text-center text-slate-400 text-xs">
                📭 ไม่พบคะแนนจัดเก็บความเดือดร้อน ณ ขณะนี้
              </div>
            ) : (
              filteredNeeds.map((need) => (
                <div
                  key={need.id}
                  className={`bg-white border border-gray-200 rounded-xl p-4 shadow-2xs hover:border-slate-300 flex flex-col md:flex-row justify-between gap-4 transition ${
                    need.status === "COMPLETED" ? "opacity-70 bg-slate-50/50" : ""
                  }`}
                >
                  <div className="space-y-2 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">
                        {need.userName}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">({need.id})</span>
                      <span
                        className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                          need.urgency.includes("ด่วนมาก")
                            ? "bg-red-100 text-red-700 border border-red-200"
                            : need.urgency.includes("ปานกลาง")
                            ? "bg-amber-100 text-amber-700 border border-amber-200"
                            : "bg-slate-100 text-slate-600 border border-gray-200"
                        }`}
                      >
                        {need.urgency}
                      </span>
                    </div>

                    <p className="text-slate-700 text-xs mt-1">
                      <span className="font-semibold text-slate-600 block">ของที่ขาดแคลน:</span>
                      {need.details}
                    </p>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 pt-1.5 border-t border-gray-100 text-slate-500 text-xs">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {need.latitude.toFixed(5)}, {need.longitude.toFixed(5)}
                      </span>
                      <a
                        href={`tel:${need.phone}`}
                        className="text-blue-600 hover:underline flex items-center gap-0.5 font-mono"
                      >
                        <Phone className="w-3 h-3 text-blue-500" />
                        {need.phone}
                      </a>
                      <span className="text-slate-400 text-[10px] font-mono">
                        {need.timestamp}
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-1 mt-2.5">
                      {need.categories.map((c, i) => (
                        <span key={i} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded border border-gray-150">
                          📦 {c}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Complete Action Button */}
                  <div className="flex items-center md:border-l md:border-gray-100 md:pl-4 shrink-0 justify-end">
                    {need.status === "PENDING" ? (
                      <button
                        id={`complete-delivery-${need.id}`}
                        onClick={() => onCompleteNeed(need.id)}
                        className="bg-amber-500 hover:bg-amber-600 text-slate-950 px-4 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        ขนส่งสำเร็จแล้ว (เสร็จสิ้น)
                      </button>
                    ) : (
                      <span className="text-xs text-slate-400 font-bold bg-slate-100 px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-slate-400" />
                        ส่งมอบเรียบร้อย
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
