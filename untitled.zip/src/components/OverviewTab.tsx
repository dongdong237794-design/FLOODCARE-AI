/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { SOSRequest, UserNeed, WaterStation } from "../types.js";
import {
  AlertCircle,
  Clock,
  CheckCircle2,
  Users2,
  FileSpreadsheet,
  TrendingUp,
  AlertTriangle,
  MapPin,
  Waves,
  Package
} from "lucide-react";

interface OverviewTabProps {
  sosRequests: SOSRequest[];
  userNeeds: UserNeed[];
  registeredUsersCount: number;
  stations: WaterStation[];
  setActiveTab: (tab: string) => void;
  syncWaterData: () => void;
  lastSyncTime: string;
}

export default function OverviewTab({
  sosRequests,
  userNeeds,
  registeredUsersCount,
  stations,
  setActiveTab,
  syncWaterData,
  lastSyncTime
}: OverviewTabProps) {
  // Compute numbers
  const totalSos = sosRequests.length;
  const openSos = sosRequests.filter((r) => r.status === "OPEN").length;
  const inProgressSos = sosRequests.filter((r) => r.status === "IN_PROGRESS").length;
  const resolvedSos = sosRequests.filter((r) => r.status === "RESOLVED").length;

  const totalNeeds = userNeeds.length;
  const pendingNeeds = userNeeds.filter((n) => n.status === "PENDING").length;
  const completedNeeds = userNeeds.filter((n) => n.status === "COMPLETED").length;

  // Alerts for water levels
  const criticalStations = stations.filter((s) => s.situation === "วิกฤต");
  const warningStations = stations.filter((s) => s.situation === "เฝ้าระวัง");

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-100">
        <div>
          <h2 className="text-2xl font-sans font-bold text-slate-800 tracking-tight">
            แดชบอร์ดสรุปวิกฤตการณ์น้ำท่วม
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            สถานะแบบเรียลไทม์ การช่วยเหลือ และข้อมูลเชื่อมต่อจาก ThaiWater API ล่าสุด
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <div className="text-right">
            <span className="block text-[11px] font-mono text-slate-400">อัปเดตล่าสุด:</span>
            <span className="text-sm font-sans font-semibold text-slate-700">
              {lastSyncTime || "กำลังสตรีมข้อมูล..."}
            </span>
          </div>
          <button
            id="sync-thaiwater-btn-overview"
            onClick={syncWaterData}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-sans text-xs font-semibold shadow-sm transition-all duration-150 flex items-center gap-2"
          >
            <Waves className="w-4 h-4" />
            ดึงข้อมูลจาก ThaiWater จริง
          </button>
        </div>
      </div>

      {/* Metrics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-white border border-gray-150 rounded-xl p-5 shadow-xs flex items-center gap-4">
          <div className="bg-red-50 p-3 rounded-xl text-red-600 shrink-0">
            <AlertCircle className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-slate-400 uppercase tracking-wider">
              แจ้งเหตุ SOS รอดักกู้ภัย
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold text-red-600 font-sans">{openSos}</span>
              <span className="text-xs text-slate-400">จากทั้งหมด {totalSos} เคส</span>
            </div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white border border-gray-150 rounded-xl p-5 shadow-xs flex items-center gap-4">
          <div className="bg-blue-50 p-3 rounded-xl text-blue-600 shrink-0">
            <Clock className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-slate-400 uppercase tracking-wider">
              อยู่ระหว่างรุดกู้ภัย
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold text-blue-600 font-sans">{inProgressSos}</span>
              <span className="text-xs text-slate-400">ประสานงานแล้ว</span>
            </div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white border border-gray-150 rounded-xl p-5 shadow-xs flex items-center gap-4">
          <div className="bg-emerald-50 p-3 rounded-xl text-emerald-600 shrink-0">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-slate-400 uppercase tracking-wider">
              ช่วยสำเร็จแล้ว
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold text-emerald-600 font-sans">{resolvedSos}</span>
              <span className="text-xs text-slate-400">ปิดเคสปลอดภัย 100%</span>
            </div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white border border-gray-150 rounded-xl p-5 shadow-xs flex items-center gap-4">
          <div className="bg-purple-50 p-3 rounded-xl text-purple-600 shrink-0">
            <Users2 className="w-6 h-6" />
          </div>
          <div>
            <span className="block text-xs font-medium text-slate-400 uppercase tracking-wider">
              ลงทะเบียนคู่สาย LINE
            </span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold text-purple-600 font-sans">{registeredUsersCount}</span>
              <span className="text-xs text-slate-400">รายชื่อพร้อมเบอร์</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Stats Panel Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Water Alerts (ThaiWater sync status) */}
        <div className="lg:col-span-2 bg-white border border-gray-200 rounded-xl shadow-xs overflow-hidden">
          <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-slate-50">
            <div className="flex items-center gap-2">
              <Waves className="w-5 h-5 text-blue-600" />
              <h3 className="font-sans font-bold text-slate-800">
                สถานีวัดน้ำไทยที่มีความเสี่ยงสูงสุด (ThaiWater Real-Time Alert)
              </h3>
            </div>
            <button
              onClick={() => setActiveTab("water")}
              className="text-xs font-semibold text-blue-600 hover:underline"
            >
              ดูทั้งหมด {stations.length} สถานี
            </button>
          </div>

          <div className="p-5 divide-y divide-gray-100 max-h-[350px] overflow-y-auto">
            {criticalStations.length === 0 && warningStations.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-sm">
                🎉 ข้อมูลระบบตรวจพบความเสถียรระดับน้ำไม่มีสถานีวิกฤตขั้นรุนแรง
              </div>
            ) : (
              [...criticalStations, ...warningStations].slice(0, 10).map((station) => (
                <div key={station.stationCode} className="py-3 flex items-center justify-between gap-4 first:pt-0 last:pb-0">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm text-slate-800">
                        {station.name}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">
                        ({station.river})
                      </span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-slate-400" />
                        {station.location}
                      </span>
                      <span>
                        ระดับปัจจุบัน: <strong className="text-slate-700">{station.waterLevel} ม.รทก.</strong>
                      </span>
                      <span>
                        ตลิ่ง: <strong>{station.bankLevel} ม.รทก.</strong>
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <span
                      className={`text-[11px] px-2.5 py-1 rounded-full font-bold uppercase min-w-[75px] text-center ${
                        station.situation === "วิกฤต"
                          ? "bg-red-100 text-red-700 border border-red-200"
                          : "bg-amber-100 text-amber-700 border border-amber-200"
                      }`}
                    >
                      {station.situation} {station.trend === "เพิ่มขึ้น" ? "↑" : station.trend === "ลดลง" ? "↓" : "→"}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Resource Demand Summary */}
        <div className="bg-white border border-gray-200 rounded-xl shadow-xs p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
              <Package className="w-5 h-5 text-amber-500" />
              <h3 className="font-sans font-bold text-slate-800">สรุปสิ่งของขาดแคลน</h3>
            </div>

            {/* Categorical demands list */}
            <div className="mt-4 space-y-3">
              {[
                { category: "🍱 อาหาร/น้ำดื่ม", count: userNeeds.filter(n => n.categories.includes("🍱 อาหาร/น้ำดื่ม") && n.status === "PENDING").length },
                { category: "💊 ยารักษาโรค/เวชภัณฑ์", count: userNeeds.filter(n => n.categories.includes("ยารักษาโรค/เวชภัณฑ์") && n.status === "PENDING").length },
                { category: "👶 นมผง/แพมเพิสเด็ก", count: userNeeds.filter(n => n.categories.includes("👶 นมผง/แพมเพิสเด็ก") && n.status === "PENDING").length },
                { category: "🧼 ของใช้ส่วนตัว/ทิชชู่", count: userNeeds.filter(n => n.categories.includes("🧼 ของใช้ส่วนตัว/ทิชชู่") && n.status === "PENDING").length },
                { category: "🔦 ไฟฉาย/แบตเตอรี่สำรอง", count: userNeeds.filter(n => n.categories.includes("🔦 ไฟฉาย/แบตเตอรี่สำรอง") && n.status === "PENDING").length }
              ].map((cat, idx) => (
                <div key={idx} className="flex justify-between items-center text-sm">
                  <span className="text-slate-600 font-medium">{cat.category}</span>
                  <div className="flex items-center gap-2">
                    <span className="h-2 w-24 bg-gray-100 rounded-full overflow-hidden inline-block relative">
                      <span
                        className="bg-amber-500 h-full absolute left-0"
                        style={{ width: `${Math.min(100, (cat.count / (totalNeeds || 1)) * 100)}%` }}
                      ></span>
                    </span>
                    <span className="font-bold text-slate-800 text-xs min-w-[20px] text-right">
                      {cat.count}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-gray-100">
            <button
              onClick={() => setActiveTab("needs")}
              className="w-full text-center bg-amber-500 hover:bg-amber-600 text-slate-950 font-semibold py-2 rounded-lg text-xs transition duration-150"
            >
              ดูรายละเอียดใบจัดจัดเสบียงอาสา
            </button>
          </div>
        </div>
      </div>

      {/* Emergency Contact Bar */}
      <div className="bg-red-50 border border-red-200 rounded-xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-6 h-6 text-red-600 shrink-0 mt-0.5" />
          <div>
            <h4 className="font-sans font-bold text-red-800 text-sm">สายด่วนกู้ชีพเพื่อความปลอดภัย</h4>
            <p className="text-xs text-red-700 mt-1">
              แผงปุ่มสำหรับการระบายผู้ป่วยหรือภัยระดับฉุกเฉิน โปรดรับโทรศัพท์และดูแลความมั่นคงของชุมชน
            </p>
          </div>
        </div>
        <div className="flex gap-2.5 shrink-0 font-mono text-xs font-bold">
          <a
            href="tel:1784"
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-center flex items-center justify-center gap-1 shadow-sm transition"
          >
            ปภ. ภัยพิบัติ โทร 1784
          </a>
          <a
            href="tel:1669"
            className="bg-stone-800 hover:bg-stone-900 text-white px-4 py-2 rounded-lg text-center flex items-center justify-center gap-1 shadow-sm transition"
          >
            กู้ชีพแพทย์ โทร 1669
          </a>
        </div>
      </div>
    </div>
  );
}
