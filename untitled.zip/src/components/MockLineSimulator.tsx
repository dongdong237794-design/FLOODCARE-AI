/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { UrgencyLevel } from "../types.js";
import {
  Smartphone,
  Send,
  MapPin,
  Check,
  AlertTriangle,
  User,
  Package,
  HelpCircle,
  X,
  Camera,
  RefreshCw,
  Clock
} from "lucide-react";

interface MockLineSimulatorProps {
  onRegisterUser: (firstName: string, lastName: string, phone: string) => void;
  onSubmitSOS: (data: {
    userName: string;
    phone: string;
    latitude: number;
    longitude: number;
    groupTypes: string[];
    urgencyLevel: string;
    note: string;
    photoUrl?: string;
  }) => void;
  onSubmitNeed: (data: {
    userName: string;
    phone: string;
    latitude: number;
    longitude: number;
    categories: string[];
    details: string;
    urgency: string;
  }) => void;
}

export default function MockLineSimulator({
  onRegisterUser,
  onSubmitSOS,
  onSubmitNeed
}: MockLineSimulatorProps) {
  // Simulator state: profile, sos, need
  const [simulatorMode, setSimulatorMode] = useState<"profile" | "sos" | "need">("profile");

  // Profile Form States
  const [profStep, setProfStep] = useState(1);
  const [profFirstName, setProfFirstName] = useState("");
  const [profLastName, setProfLastName] = useState("");
  const [profPhone, setProfPhone] = useState("");

  // SOS Form States (Step 1-5)
  const [sosStep, setSosStep] = useState(1);
  const [sosLat, setSosLat] = useState<number>(14.3565);
  const [sosLon, setSosLon] = useState<number>(100.5580);
  const [sosGroups, setSosGroups] = useState<string[]>([]);
  const [sosUrgency, setSosUrgency] = useState("🔴 วิกฤต (มิดหัว/ติดบนหลังคา)");
  const [sosPhoto, setSosPhoto] = useState<string>("");
  const [sosNote, setSosNote] = useState("");

  // Needs Form States (Step 1-5)
  const [needStep, setNeedStep] = useState(1);
  const [needLat, setNeedLat] = useState<number>(14.3582);
  const [needLon, setNeedLon] = useState<number>(100.5592);
  const [needCats, setNeedCats] = useState<string[]>([]);
  const [needDetails, setNeedDetails] = useState("");
  const [needUrgency, setNeedUrgency] = useState("ด่วนมาก (หมดแล้ว)");

  // Log of simulated chat message balloons inside device
  const [phoneChats, setPhoneChats] = useState<Array<{ sender: "bot" | "user"; text: string; action?: any }>>([
    {
      sender: "bot",
      text: "💚 ยินดีต้อนรับสู่คู่สายไลน์กู้ชีวิดภัยพิบัติ FLOODCARE ครับ! กรุณากรอก 'ชื่อจริง' ของคุณเพื่อเริ่มลงทะเบียนด่วนครับ"
    }
  ]);

  const groupOptions = [
    "ผู้ป่วยติดเตียง/พิการ",
    "มีเด็กเล็ก/คนชรา",
    "ผู้บาดเจ็บฉุกเฉิน",
    "ผู้ใหญ่ทั่วไป",
    "สัตว์เลี้ยง/ปศุสัตว์"
  ];

  const urgencyOptions = [
    "🔴 วิกฤต (มิดหัว/ติดบนหลังคา)",
    "🟠 สูง (ระดับอก/เกิน 1 เมตร)",
    "🟡 ปานกลาง (ระดับเอว/น้อยกว่า 1 เมตร)",
    "🟢 ต่ำ (ระดับตาตุ่ม/เริ่มล้นตลิ่ง)",
    "💊 ขาดแคลนอาหาร/ยา ประกายไฟรั่ว"
  ];

  const needCatOptions = [
    "🍱 อาหาร/น้ำดื่ม",
    "ยารักษาโรค/เวชภัณฑ์",
    "👶 นมผง/แพมเพิสเด็ก",
    "🧼 ของใช้ส่วนตัว/ทิชชู่",
    "🔦 ไฟฉาย/แบตเตอรี่สำรอง",
    "📝 อื่นๆ"
  ];

  const needUrgencyOptions = [
    "ด่วนมาก (หมดแล้ว)",
    "ปานกลาง (รอได้ 24 ชม.)",
    "ไม่ด่วน (แจ้งไว้ล่วงหน้า)"
  ];

  // Helper mock photo links
  const samplePhotos = [
    { name: "น้ำท่วมระดับอก", path: "https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&q=80&w=400" },
    { name: "ติดบนหลังคาบ้าน", path: "https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?auto=format&fit=crop&q=80&w=400" }
  ];

  const addChat = (sender: "bot" | "user", text: string) => {
    setPhoneChats((prev) => [...prev, { sender, text }]);
  };

  // Profile process
  const proceedProfile = () => {
    if (profStep === 1) {
      if (!profFirstName.trim()) return;
      addChat("user", profFirstName);
      addChat("bot", `ขอบคุณครับ คุณ ${profFirstName} ต่อไปขอนามสกุลจริงด้วยครับ`);
      setProfStep(2);
    } else if (profStep === 2) {
      if (!profLastName.trim()) return;
      addChat("user", profLastName);
      addChat("bot", `รับทราบครับ ต่อไปกรุณากรอกเบอร์โทรสำคัญ 10 หลัก เพื่อการประสานส่งเรือเข้ากู้ภัยครับ`);
      setProfStep(3);
    } else if (profStep === 3) {
      if (profPhone.length < 9) return;
      addChat("user", profPhone);
      onRegisterUser(profFirstName, profLastName, profPhone);
      addChat(
        "bot",
        `🎉 ขอบคุณครับ! ลงทะเบียนหมายเลขสำเร็จ:\n👤 ชื่อ: ${profFirstName} ${profLastName}\n📞 เบอร์: ${profPhone}\n\nตอนนี้คุณสามารถใช้ปุ่มทางลัดส่งพิกัดแจ้งช่วย SOS หรือขอจัดเสบียงได้ตลอดเวลาครับ!`
      );
      setProfStep(4);
    }
  };

  // Reset flows
  const resetSOSSimulator = () => {
    setSosStep(1);
    setSosGroups([]);
    setSosUrgency("🔴 วิกฤต (มิดหัว/ติดบนหลังคา)");
    setSosPhoto("");
    setSosNote("");
  };

  const resetNeedSimulator = () => {
    setNeedStep(1);
    setNeedCats([]);
    setNeedDetails("");
    setNeedUrgency("ด่วนมาก (หมดแล้ว)");
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-[550px]">
      {/* Simulation panel description (Left cols 5) */}
      <div className="lg:col-span-5 flex flex-col justify-between space-y-4 pr-2">
        <div className="space-y-3">
          <div className="inline-block bg-blue-50 text-blue-800 text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded">
            📱 LINE Bot Multi-Step Playground
          </div>
          <h2 className="text-xl font-sans font-bold text-slate-800">
            จำลองคู่สายโทรศัพท์ LINE Bot แมนนวล
          </h2>
          <p className="text-xs text-slate-600 leading-relaxed">
            ทดสอบการทำเงื่อนไขแบบ Step-by-Step ของแอปพลิเคชัน โดยหน้าขวาทำตัวเสมือนแชตของคุณบน LINE 
            กดตอบตัวเลือกเพื่อส่งข้อมูลพิกัด ระบุกลุ่มเปราะบาง และรูปถ่ายหลักฐาน จากนั้นข้อมูลจะปรากฏบนบอร์ดแจ้งเหตุกู้ภัยทันที
          </p>

          {/* Mode selections */}
          <div className="space-y-2 pt-3 border-t border-gray-150">
            <span className="block text-xs font-semibold text-slate-400">เลือกโปรโตคอลการจำลอง:</span>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  setSimulatorMode("profile");
                  setProfStep(1);
                  setProfFirstName("");
                  setProfLastName("");
                  setProfPhone("");
                  setPhoneChats([
                    {
                      sender: "bot",
                      text: "💚 ยินดีต้อนรับสู่คู่สายไลน์กู้ชีวิดภัยพิบัติ FLOODCARE ครับ! กรุณากรอก 'ชื่อจริง' ของคุณเพื่อเริ่มลงทะเบียนด่วนครับ"
                    }
                  ]);
                }}
                className={`py-2 px-1 text-center rounded-lg text-[11px] font-bold border transition ${
                  simulatorMode === "profile"
                    ? "bg-blue-600 text-white border-blue-600"
                    : "bg-slate-50 text-slate-600 border-gray-200 hover:bg-slate-100"
                }`}
              >
                1. ลงทะเบียนเบอร์
              </button>

              <button
                onClick={() => {
                  setSimulatorMode("sos");
                  resetSOSSimulator();
                  setPhoneChats([
                    {
                      sender: "bot",
                      text: "🚨 [ปุ่มทางลัดกด SOS เข้ามา] ยินดีต้อนรับสู่โปรโตคอลแจ้งขอเรือกู้ชีพฉุกเฉิน\n\n📌 ขั้นที่ 1: กรุณากดแชร์พิกัดสถานที่ตกค้างของคุณครับ"
                    }
                  ]);
                }}
                className={`py-2 px-1 text-center rounded-lg text-[11px] font-bold border transition ${
                  simulatorMode === "sos"
                    ? "bg-red-600 text-white border-red-600"
                    : "bg-slate-50 text-slate-600 border-gray-200 hover:bg-slate-100"
                }`}
              >
                2. แจ้งวิกฤต SOS
              </button>

              <button
                onClick={() => {
                  setSimulatorMode("need");
                  resetNeedSimulator();
                  setPhoneChats([
                    {
                      sender: "bot",
                      text: "📦 [ปุ่มทางลัดแจ้งสิ่งของเสบียง] สู่ระบบแจกถุงยังชีพและแพ็กยาเวชภัณฑ์\n\n📌 ขั้นที่ 1: กรุณาแชร์จุดรับสิ่งของ (📍 แชร์โลเคชัน) เพื่อเริ่มลงลิสต์จัดของครับ"
                    }
                  ]);
                }}
                className={`py-2 px-1 text-center rounded-lg text-[11px] font-bold border transition ${
                  simulatorMode === "need"
                    ? "bg-amber-500 text-slate-950 border-amber-500"
                    : "bg-slate-50 text-slate-600 border-gray-200 hover:bg-slate-100"
                }`}
              >
                3. ขอรับปันเสบียง
              </button>
            </div>
          </div>
        </div>

        {/* Survival instructions generator card */}
        <div className="bg-slate-50 border border-gray-150 p-4 rounded-xl">
          <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            คำแนะนำประหยัดพลังงานในระดับชีวิตสูงสุด:
          </h4>
          <ul className="text-[11px] text-slate-600 mt-2 space-y-1.5 list-disc pl-4.5 font-medium">
            <li>ปิดสัญญาณไวไฟและบลูทูธเพื่อเก็บกระแสแบตสำรองไว้ใช้ยามกลางคืน</li>
            <li>ใช้วิธีสื่อสารผ่านแชตแทนโทรออกบอทไลน์จะรวบรวมพิกัดได้ถาวร</li>
            <li>ห้ามแตะต้องสวิตช์เครื่องใช้ไฟฟ้าที่จมน้ำเด็ดขาด</li>
          </ul>
        </div>
      </div>

      {/* Visual Dynamic smartphone device casing (Right col 7) */}
      <div className="lg:col-span-7 flex justify-center">
        <div className="w-full max-w-[340px] bg-slate-950 rounded-[40px] p-3.5 border-4 border-slate-800 shadow-xl relative aspect-[9/18] flex flex-col overflow-hidden">
          {/* Smartphone notches ear-piece */}
          <div className="absolute top-0.5 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-950 rounded-b-2xl z-20 flex justify-center items-center">
            <div className="w-12 h-1 bg-slate-805 rounded-full mb-1"></div>
          </div>

          {/* Device display area */}
          <div className="flex-1 rounded-[28px] bg-[#829bb5] flex flex-col justify-between overflow-hidden relative border border-slate-900 pt-7 p-3">
            {/* Top header custom styled LINE App */}
            <div className="bg-[#242e3a] p-2 rounded-xl flex items-baseline justify-between shrink-0 mb-2">
              <span className="text-[10px] text-slate-300 font-bold font-mono">FC FLOODCARE BOT</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
            </div>

            {/* Bubble chat area */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-0.5 mb-2.5">
              {phoneChats.map((ch, idx) => {
                const isBot = ch.sender === "bot";
                return (
                  <div key={idx} className={`flex ${isBot ? "justify-start" : "justify-end"}`}>
                    <div
                      className={`max-w-[85%] text-[11px] px-3 py-2 rounded-xl shadow-3xs leading-relaxed whitespace-pre-wrap ${
                        isBot
                          ? "bg-white text-slate-800 border rounded-tl-none font-medium"
                          : "bg-[#4da94a] text-white rounded-tr-none font-semibold"
                      }`}
                    >
                      {ch.text}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Step form input context controls (Line Bot Rich Menu Simulator) */}
            <div className="bg-white rounded-xl p-3 shadow-sm border border-slate-200 shrink-0 space-y-3">
              {/* --- mode 1: PROFILE REGISTER STEPPER --- */}
              {simulatorMode === "profile" && (
                <div className="space-y-2">
                  <div className="text-[10px] font-bold text-blue-600 block">
                    ขั้นตอนลงทะเบียนคู่สาย LINE - STEP {profStep} / 3:
                  </div>

                  {profStep === 1 && (
                    <div className="space-y-1">
                      <input
                        type="text"
                        placeholder="พิมพ์ชื่อจริงของคุณ..."
                        value={profFirstName}
                        onChange={(e) => setProfFirstName(e.target.value)}
                        className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none"
                      />
                      <button
                        onClick={proceedProfile}
                        className="w-full bg-[#4da94a] text-white text-xs py-1.5 rounded font-bold"
                      >
                        ส่งข้อความตอบ
                      </button>
                    </div>
                  )}

                  {profStep === 2 && (
                    <div className="space-y-1">
                      <input
                        type="text"
                        placeholder="พิมพ์นามสกุลของคุณ..."
                        value={profLastName}
                        onChange={(e) => setProfLastName(e.target.value)}
                        className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none"
                      />
                      <button
                        onClick={proceedProfile}
                        className="w-full bg-[#4da94a] text-white text-xs py-1.5 rounded font-bold"
                      >
                        ส่งข้อความตอบ
                      </button>
                    </div>
                  )}

                  {profStep === 3 && (
                    <div className="space-y-1">
                      <input
                        type="tel"
                        maxLength={10}
                        placeholder="พิมพ์เบอร์โทรติดต่อ..."
                        value={profPhone}
                        onChange={(e) => setProfPhone(e.target.value)}
                        className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none"
                      />
                      <button
                        onClick={proceedProfile}
                        className="w-full bg-[#4da94a] text-white text-xs py-1.5 rounded font-bold"
                      >
                        เซฟข้อมูลลงฐานกู้ภัย
                      </button>
                    </div>
                  )}

                  {profStep >= 4 && (
                    <div className="text-center text-[10px] text-slate-400 font-bold py-2">
                      ลงทะเบียนเสร็จสิ้น เปลี่ยนประเภทจำลองเป็น SOS ด้านซ้ายเพื่อเริ่มเทสได้เลย!
                    </div>
                  )}
                </div>
              )}

              {/* --- mode 2: EMERGENCY SOS STEPPER (Step 1-5) --- */}
              {simulatorMode === "sos" && (
                <div className="space-y-2">
                  <div className="text-[10px] font-bold text-red-600 block">
                    ขั้นตอนแจ้งกู้ชีพ SOS - STEP {sosStep} / 5:
                  </div>

                  {/* Step 1: Location */}
                  {sosStep === 1 && (
                    <div className="space-y-1">
                      <p className="text-[10px] text-slate-500">📍 จำลองปักหมุด GPS ในอยุธยา หรือ พัทลุง:</p>
                      <div className="grid grid-cols-2 gap-1.5 text-[9px]">
                        <button
                          onClick={() => {
                            setSosLat(14.3565);
                            setSosLon(100.5580);
                            addChat("user", "📍 ตกค้างพิกัด อ.บางบาล อยุธยา (14.3565, 100.5580)");
                            addChat("bot", "📌 ขั้นที่ 2: มีผู้ที่ต้องการช่วยเหลือกลุ่มใดพำนักอยู่ด้วยบ้าง? (เลือกทั้งหมดที่ใช่)");
                            setSosStep(2);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 p-1 rounded font-bold text-slate-700"
                        >
                          บางบาล พระนครศรีอยุธยา
                        </button>
                        <button
                          onClick={() => {
                            setSosLat(7.0145);
                            setSosLon(100.4595);
                            addChat("user", "📍 ตกค้างพิกัด อ.หาดใหญ่ สงขลา (7.0145, 100.4595)");
                            addChat("bot", "📌 ขั้นที่ 2: มีผู้ที่ต้องการช่วยเหลือกลุ่มใดพำนักอยู่ด้วยบ้าง? (เลือกทั้งหมดที่ใช่)");
                            setSosStep(2);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 p-1 rounded font-bold text-slate-705"
                        >
                          หาดใหญ่ ลุ่มอู่ตะเภา
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Step 2: Groups */}
                  {sosStep === 2 && (
                    <div className="space-y-1.5">
                      <div className="grid grid-cols-1 gap-1">
                        {groupOptions.map((opt) => (
                          <label key={opt} className="flex items-center gap-1.5 text-[10px] text-slate-700 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={sosGroups.includes(opt)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSosGroups([...sosGroups, opt]);
                                } else {
                                  setSosGroups(sosGroups.filter((g) => g !== opt));
                                }
                              }}
                              className="w-3.5 h-3.5 text-red-600 rounded border-slate-300"
                            />
                            <span>{opt}</span>
                          </label>
                        ))}
                      </div>
                      <button
                        onClick={() => {
                          if (sosGroups.length === 0) return;
                          addChat("user", `กลุ่มตกค้าง: ${sosGroups.join(", ")}`);
                          addChat("bot", "📌 ขั้นที่ 3: ประเมินระดับน้ำและความรุนแรงของที่อยู่อาศัยคุณตอนนี้:");
                          setSosStep(3);
                        }}
                        className="w-full bg-[#4da94a] text-white text-[10px] py-1.5 rounded font-bold"
                      >
                        ยืนยันกลุ่มและไปขั้นตอนที่ 3
                      </button>
                    </div>
                  )}

                  {/* Step 3: Urgency / Water details */}
                  {sosStep === 3 && (
                    <div className="space-y-1">
                      <select
                        value={sosUrgency}
                        onChange={(e) => setSosUrgency(e.target.value)}
                        className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none"
                      >
                        {urgencyOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={() => {
                          addChat("user", `ระดับความรุนแรง: ${sosUrgency}`);
                          addChat(
                            "bot",
                            "📌 ขั้นที่ 4: อัปโหลดรูปถ่ายหน้างานจริงเพื่อประเมินเรือ (หรือกดปุ่ม 'ข้ามรูปถ่าย' ได้เลยครับ)"
                          );
                          setSosStep(4);
                        }}
                        className="w-full bg-[#4da94a] text-white text-xs py-1.5 rounded font-bold mt-1"
                      >
                        ส่งประเมินน้ำท่วม
                      </button>
                    </div>
                  )}

                  {/* Step 4: Photo attachment or Skip */}
                  {sosStep === 4 && (
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-1.5">
                        {samplePhotos.map((p, i) => (
                          <button
                            key={i}
                            onClick={() => {
                              setSosPhoto(p.path);
                              addChat("user", `[📸 อัปโหลดรูปภาพ: ${p.name}]`);
                              addChat("bot", "📌 ขั้นที่ 5: กรุณาเขียนข้อความระบุเพิ่มเติม หรือกดข้ามเพื่อตรวจดูใบสมัครสรุป:");
                              setSosStep(5);
                            }}
                            className="bg-slate-100 hover:bg-slate-200 p-1 border rounded text-[9px] text-slate-700 flex flex-col items-center gap-1"
                          >
                            <Camera className="w-3.5 h-3.5 text-blue-500" />
                            {p.name}
                          </button>
                        ))}
                      </div>
                      <button
                        onClick={() => {
                          setSosPhoto("");
                          addChat("user", "⏩ ข้ามพายอัปโหลดรูป");
                          addChat("bot", "📌 ขั้นที่ 5: กรุณาเขียนข้อความระบุเพิ่มเติม หรือกดข้ามเพื่อตรวจดูใบสมัครสรุป:");
                          setSosStep(5);
                        }}
                        className="w-full text-center text-[10px] text-blue-600 font-bold hover:underline py-1"
                      >
                        ข้ามรูปถ่าย
                      </button>
                    </div>
                  )}

                  {/* Step 5: Summary with Confirm or Cancel */}
                  {sosStep === 5 && (
                    <div className="space-y-2">
                      <textarea
                        placeholder="ระบุข้อความแวดล้อม เช่น แบตใกล้หมด มีเด็ก 2 คน..."
                        value={sosNote}
                        onChange={(e) => setSosNote(e.target.value)}
                        className="w-full text-[10px] p-2 border border-slate-300 rounded outline-none h-12"
                      ></textarea>

                      <div className="bg-red-50 p-2 rounded border border-red-200 text-[10px] text-red-800 space-y-1">
                        <div className="font-bold">ตรวจสอบข้อมูล SOS:</div>
                        <div>• กลุ่มผู้ประสบภัย: {sosGroups.join(", ")}</div>
                        <div>• ระดับน้ำหลัก: {sosUrgency}</div>
                        {sosNote && <div>• บันทึก: {sosNote}</div>}
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => {
                            onSubmitSOS({
                              userName: profFirstName ? `${profFirstName} ${profLastName}` : "สิมูเลเตอร์ LINE บอท",
                              phone: profPhone || "081-111-2222",
                              latitude: sosLat,
                              longitude: sosLon,
                              groupTypes: sosGroups,
                              urgencyLevel: sosUrgency,
                              note: sosNote,
                              photoUrl: sosPhoto
                            });
                            addChat("user", "✅ ยืนยันคำขอ SOS สำเร็จ");
                            addChat(
                              "bot",
                              "🚨 ระบบได้รับสัญญาณส่งเรื่องกู้ชีพแล้วครับ!\n\n🩹 ทางทีมกู้ภัยบนแดชบอร์ดส่วนกลางกำลังประสานหาสถานีกู้ชีพใกล้เคียง\n\n📌 โปรดจำไว้ขึ้นที่สูงตัดไฟและประหยัดแบตเตอรี่ครับ!"
                            );
                            setSosStep(6);
                          }}
                          className="bg-red-650 hover:bg-red-700 text-white font-bold py-1.5 rounded text-[11px]"
                        >
                          [✅ ยืนยันส่ง SOS]
                        </button>
                        <button
                          onClick={() => {
                            addChat("user", "❌ ยกเลิกคำขอ");
                            addChat("bot", "ยกเลิกเรียบร้อยแล้วครับ ปลอดภัยไว้ก่อนเสมอนะครับ");
                            resetSOSSimulator();
                          }}
                          className="bg-slate-100 text-slate-600 py-1.5 rounded text-[11px]"
                        >
                          [❌ ยกเลิก]
                        </button>
                      </div>
                    </div>
                  )}

                  {sosStep >= 6 && (
                    <div className="text-center text-[10px] text-[#4da94a] font-bold py-2 flex flex-col items-center">
                      <Check className="w-5 h-5" />
                      ส่งเรื่องช่วยเหลือ SOS สำเร็จ ดูเคสของคุณในแท็บ "สถิติกู้ชีพและสั่งการ SOS" ได้ทันทีครับ!
                    </div>
                  )}
                </div>
              )}

              {/* --- mode 3: USER NEEDS PACKS STEPPER (Step 1-5) --- */}
              {simulatorMode === "need" && (
                <div className="space-y-2">
                  <div className="text-[10px] font-bold text-amber-600 block">
                    ขั้นตอนขอรับเสบียง - STEP {needStep} / 5:
                  </div>

                  {/* Step 1: Coordinates */}
                  {needStep === 1 && (
                    <div className="space-y-1">
                      <p className="text-[10px] text-slate-500">📍 จำลองแชร์พิกัดพิกัดจัดแจกถุงยังชีพ:</p>
                      <div className="grid grid-cols-2 gap-1.5 text-[9px]">
                        <button
                          onClick={() => {
                            setNeedLat(14.3582);
                            setNeedLon(100.5592);
                            addChat("user", "📍 แชร์จุดรับของ บางบาล อยุธยา (14.3582, 100.5592)");
                            addChat("bot", "📌 ขั้นที่ 2: ติ๊กเลือกประเภทของส่งบรรเทาที่ยังขาดแคลน:");
                            setNeedStep(2);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 p-1 rounded font-bold text-slate-700"
                        >
                          จุดพิกัดวัดบางกะทิง อยุธยา
                        </button>
                        <button
                          onClick={() => {
                            setNeedLat(7.0125);
                            setNeedLon(100.4560);
                            addChat("user", "📍 แชร์จุดรับของ หาดใหญ่ สงขลา (7.0125, 100.4560)");
                            addChat("bot", "📌 ขั้นที่ 2: ติ๊กเลือกประเภทของส่งบรรเทาที่ยังขาดแคลน:");
                            setNeedStep(2);
                          }}
                          className="bg-slate-100 hover:bg-slate-200 p-1 rounded font-bold text-slate-705"
                        >
                          จุดพิกัดตลาดกิมหยง หาดใหญ่
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Step 2: Categories selection */}
                  {needStep === 2 && (
                    <div className="space-y-1 bg-slate-50 p-1.5 rounded">
                      <div className="grid grid-cols-2 gap-1 text-[9px]">
                        {needCatOptions.map((opt) => (
                          <label key={opt} className="flex items-center gap-1 text-slate-755 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={needCats.includes(opt)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setNeedCats([...needCats, opt]);
                                } else {
                                  setNeedCats(needCats.filter((c) => c !== opt));
                                }
                              }}
                              className="w-3 h-3 text-amber-500"
                            />
                            <span>{opt}</span>
                          </label>
                        ))}
                      </div>
                      <button
                        onClick={() => {
                          if (needCats.length === 0) return;
                          addChat("user", `ต้องการเสบียง: ${needCats.join(", ")}`);
                          addChat("bot", "📌 ขั้นที่ 3: ระบุนมผง อาหารกล่อง และสัดส่วนสิ่งของที่ต้องการเพิ่มเติมครับ:");
                          setNeedStep(3);
                        }}
                        className="w-full bg-[#4da94a] text-white text-[10px] py-1 mt-1.5 rounded font-bold"
                      >
                        ยืนยันและไปขั้นที่ 3
                      </button>
                    </div>
                  )}

                  {/* Step 3: Specific comments */}
                  {needStep === 3 && (
                    <div className="space-y-1">
                      <input
                        type="text"
                        placeholder="ระบุเพิ่มเติม เช่น นมเด็กทารกแรกเกิด 1 กล่อง, ข้าวกะเพรา 3 กล่อง..."
                        value={needDetails}
                        onChange={(e) => setNeedDetails(e.target.value)}
                        className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none"
                      />
                      <button
                        onClick={() => {
                          addChat("user", `ระบุของเพิ่มเติม: ${needDetails}`);
                          addChat("bot", "📌 ขั้นที่ 4: ความเร่งด่วนของเสบียงในครัวเรือนของคุณในตอนนี้คือระดับใด?");
                          setNeedStep(4);
                        }}
                        className="w-full bg-[#4da94a] text-white text-xs py-1 rounded font-bold"
                      >
                        พิมพ์ตอบข้อมูล
                      </button>
                    </div>
                  )}

                  {/* Step 4: Urgency selections */}
                  {needStep === 4 && (
                    <div className="space-y-1">
                      <select
                        value={needUrgency}
                        onChange={(e) => setNeedUrgency(e.target.value)}
                        className="w-full text-xs p-1.5 border border-slate-300 rounded outline-none"
                      >
                        {needUrgencyOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                      <button
                        onClick={() => {
                          addChat("user", `ระดับความจำเป็น: ${needUrgency}`);
                          addChat("bot", "📌 ขั้นที่ 5: ตรวจทานรายงานความเดือดร้อนถุงยังชีพ และขอยืนยันคำสั่งจัดรวม:");
                          setNeedStep(5);
                        }}
                        className="w-full bg-[#4da94a] text-white text-xs py-1 rounded font-bold mt-1"
                      >
                        ส่งประเมินความจำเป็น
                      </button>
                    </div>
                  )}

                  {/* Step 5: Master summary confirmations */}
                  {needStep === 5 && (
                    <div className="space-y-2">
                      <div className="bg-amber-50 p-2 rounded border border-amber-200 text-[10px] text-amber-800 space-y-1">
                        <div className="font-bold">สรุปรายการถุงยังชีพ:</div>
                        <div>• เสบียง: {needCats.join(", ")}</div>
                        {needDetails && <div>• ของต้องการพิเศษ: {needDetails}</div>}
                        <div>• ระดับจำเป็น: {needUrgency}</div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={() => {
                            onSubmitNeed({
                              userName: profFirstName ? `${profFirstName} ${profLastName}` : "สิมูเลเตอร์ LINE เสบียง",
                              phone: profPhone || "089-999-0000",
                              latitude: needLat,
                              longitude: needLon,
                              categories: needCats,
                              details: needDetails,
                              urgency: needUrgency
                            });
                            addChat("user", "✅ ยืนยันคำขอรับข้าวกล่องยังชีพ");
                            addChat(
                              "bot",
                              "📦 ขอบคุณข้อมูลครับ! ระบบลงบัญชีการบรรจุใบยังชีพแล้ว ตรวจสอบสปอตได้ที่รายการ 'ความช่วยเหลือเสบียง' อาสาสมัครกำลังแพ็กแป้งและเวชภัณฑ์เพื่อนำส่งครับ"
                            );
                            setNeedStep(6);
                          }}
                          className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-1.5 rounded text-[11px]"
                        >
                          [✅ ยืนยันใบจัดของ]
                        </button>
                        <button
                          onClick={() => {
                            addChat("user", "❌ ยกเลิกจัดเสบียง");
                            addChat("bot", "ยกเลิกแล้วครับ ตรวจน้ำตลิ่งปลอดภัยร่วมกตัญญูกันต่อนะครับ");
                            resetNeedSimulator();
                          }}
                          className="bg-slate-100 text-slate-600 py-1.5 rounded text-[11px]"
                        >
                          [❌ ยกเลิก]
                        </button>
                      </div>
                    </div>
                  )}

                  {needStep >= 6 && (
                    <div className="text-center text-[10px] text-[#4da94a] font-bold py-2 flex flex-col items-center">
                      <Check className="w-5 h-5 text-emerald-500" />
                      จัดแจกถุงยังชีพสำเร็จ! ดูแผนงานการแพ็กของอาสาสมัครได้ในแท็บบอร์ด "ความช่วยเหลือเสบียง" ครับ
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
