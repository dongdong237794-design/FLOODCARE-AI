/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { WaterStation } from "../types.js";
import {
  Search,
  RefreshCw,
  SlidersHorizontal,
  MapPin,
  Compass,
  AlertOctagon,
  HelpCircle
} from "lucide-react";

interface WaterTabProps {
  stations: WaterStation[];
  syncWaterData: () => void;
  syncing: boolean;
  lastSyncTime: string;
}

export default function WaterTab({
  stations,
  syncWaterData,
  syncing,
  lastSyncTime
}: WaterTabProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSituation, setFilterSituation] = useState("all");
  const [filterProvince, setFilterProvince] = useState("all");
  const [userCoords, setUserCoords] = useState<{ lat: number; lon: number } | null>(null);
  const [locationError, setLocationError] = useState("");
  const [calculatingDist, setCalculatingDist] = useState(false);

  // Extract unique provinces
  const provinces = ["all", ...new Set(stations.map((s) => s.location).filter(Boolean))];

  // Ask for Geolocation
  const requestLocation = () => {
    setCalculatingDist(true);
    if (!navigator.geolocation) {
      setLocationError("เบราว์เซอร์ของคุณไม่ซัพพอร์ตระบบตระหนักพิกัดพิกัดภูมิศาสตร์");
      setCalculatingDist(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setUserCoords({
          lat: pos.coords.latitude,
          lon: pos.coords.longitude
        });
        setLocationError("");
        setCalculatingDist(false);
      },
      (err) => {
        console.error("Geolocation error:", err);
        setLocationError("กรุณาอนุญาตการเข้าถึงพิกัด GPS บนเบราว์เซอร์ของคุณเพื่อคำนวณระยะห่าง");
        setCalculatingDist(false);
      },
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  // Distance helper in-tab
  function getDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
    const R = 6371;
    const dlat = ((lat2 - lat1) * Math.PI) / 180;
    const dlon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dlat / 2) * Math.sin(dlat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dlon / 2) *
        Math.sin(dlon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  // Filter & process stations
  const processedStations = stations
    .map((st) => {
      let distanceValue: number | null = null;
      if (userCoords) {
        distanceValue = getDistance(userCoords.lat, userCoords.lon, st.lat, st.lon);
      }
      return { ...st, distanceValue };
    })
    .filter((st) => {
      const matchSearch =
        st.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        st.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
        st.river.toLowerCase().includes(searchTerm.toLowerCase());

      const matchSituation =
        filterSituation === "all" || st.situation === filterSituation;

      const matchProvince = filterProvince === "all" || st.location === filterProvince;

      return matchSearch && matchSituation && matchProvince;
    });

  // Sort: if user has computed coordinates, sort by closest distance, otherwise keep default sorting
  if (userCoords) {
    processedStations.sort((a, b) => {
      if (a.distanceValue === null) return 1;
      if (b.distanceValue === null) return -1;
      return a.distanceValue - b.distanceValue;
    });
  }

  return (
    <div className="space-y-6">
      {/* Tab Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-gray-100">
        <div>
          <h2 className="text-2xl font-sans font-bold text-slate-800 tracking-tight flex items-center gap-2">
            ข้อมูลระดับน้ำและเฝ้าระวังตลิ่ง (ThaiWater API)
          </h2>
          <p className="text-sm text-slate-500 mt-1">
            ข้อมูลระดับน้ำจริง 738 สถานี จากโทรมาตรระวังภัยลุ่มน้ำประเทศ ไร้ข้อมูลสมมติ 
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Proximity button */}
          <button
            onClick={requestLocation}
            disabled={calculatingDist}
            className={`px-3.5 py-2 rounded-lg text-xs font-semibold font-sans flex items-center gap-1.5 transition ${
              userCoords
                ? "bg-emerald-50 text-emerald-800 border border-emerald-200"
                : "bg-slate-100 text-slate-700 hover:bg-slate-200 border border-gray-200"
            }`}
          >
            <Compass className={`w-4 h-4 ${calculatingDist ? "animate-spin text-blue-600" : ""}`} />
            {userCoords
              ? `พิกัด GPS: ${userCoords.lat.toFixed(4)}, ${userCoords.lon.toFixed(4)}`
              : "คำนวณสถานีที่ใกล้ฉันที่สุด"}
          </button>

          {/* Sync Button */}
          <button
            onClick={syncWaterData}
            disabled={syncing}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-xs font-semibold shadow-sm transition disabled:opacity-75 flex items-center gap-2"
          >
            <RefreshCw className={`w-4 h-4 ${syncing ? "animate-spin" : ""}`} />
            {syncing ? "กำลังดึงข้อมูล API..." : "ดึงข้อมูลจาก ThaiWater จริง"}
          </button>
        </div>
      </div>

      {/* Geolocation feedback alert */}
      {locationError && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-xs text-amber-800 flex items-center gap-2">
          <AlertOctagon className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{locationError}</span>
        </div>
      )}

      {/* Interactive Controls Filter Block */}
      <div className="bg-white border border-gray-150 p-4 rounded-xl flex flex-col md:flex-row gap-4 items-center">
        {/* Search */}
        <div className="relative w-full md:flex-1">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="water-search-input"
            type="text"
            placeholder="ค้นหาชื่อสถานี, แม่น้ำ, หรือจังหวัด..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-lg text-sm bg-gray-50 focus:bg-white outline-none transition"
          />
        </div>

        {/* Sliders Option filters */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <SlidersHorizontal className="w-4 h-4 text-slate-400" />
            <span className="text-xs text-slate-500 whitespace-nowrap">สถานการณ์:</span>
            <select
              value={filterSituation}
              onChange={(e) => setFilterSituation(e.target.value)}
              className="px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs bg-white text-slate-700 rounded-md outline-none focus:ring-1 focus:ring-blue-500"
            >
              <option value="all">ทั้งหมด</option>
              <option value="ปกติ">ปกติ (ระดับปลอดภัย)</option>
              <option value="เฝ้าระวัง">เฝ้าระวัง (ระดับปานกลาง)</option>
              <option value="วิกฤต">วิกฤต (ล้นตลิ่ง/ท่วม)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto">
            <span className="text-xs text-slate-500 whitespace-nowrap">จังหวัด:</span>
            <select
              value={filterProvince}
              onChange={(e) => setFilterProvince(e.target.value)}
              className="px-2.5 py-1.5 border border-gray-200 rounded-lg text-xs bg-white text-slate-700 rounded-md outline-none focus:ring-1 focus:ring-blue-500 max-w-[150px]"
            >
              <option value="all">ทั้งหมด</option>
              {provinces.filter(p => p !== "all").slice(0, 30).map((p, idx) => (
                <option key={idx} value={p}>{p}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Datatable */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-gray-200 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                {userCoords && <th className="p-4">ลำดับใกล้สุด</th>}
                <th className="p-4">รหัส</th>
                <th className="p-4">ชื่อสถานี / แม่น้ำ / จังหวัด</th>
                <th className="p-4 text-center">ระดับน้ำปัจจุบัน (ม.รทก.)</th>
                <th className="p-4 text-center">ระดับตลิ่งสูงสุด (ม.รทก.)</th>
                <th className="p-4 text-center">สถานการณ์</th>
                <th className="p-4 text-center">แนวโน้ม</th>
                <th className="p-4 text-center">อัปเดต</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-150 text-xs">
              {processedStations.length === 0 ? (
                <tr>
                  <td colSpan={userCoords ? 8 : 7} className="p-8 text-center text-slate-400">
                    ไม่พบข้อมูลจุดโทรมาตรที่ระบุ ค้นหาใหม่อีกครั้ง
                  </td>
                </tr>
              ) : (
                processedStations.slice(0, 100).map((st, idx) => {
                  return (
                    <tr key={st.stationCode} className="hover:bg-slate-50/50 transition duration-100">
                      {userCoords && (
                        <td className="p-4 font-mono font-bold text-blue-600">
                          {st.distanceValue !== null ? `${st.distanceValue.toFixed(1)} km` : "-"}
                        </td>
                      )}
                      <td className="p-4 font-mono text-slate-400 font-semibold">{st.stationCode}</td>
                      <td className="p-4">
                        <div className="space-y-1">
                          <span className="font-bold text-slate-800 text-sm block">
                            {st.name}
                          </span>
                          <div className="flex items-center gap-2 text-slate-400">
                            <span>แม่น้ำ: <strong className="text-slate-600 font-medium">{st.river}</strong></span>
                            <span className="text-stone-300">|</span>
                            <span className="flex items-center gap-0.5">
                              <MapPin className="w-3 h-3 text-slate-400 inline" />
                              {st.location}
                            </span>
                          </div>
                        </div>
                      </td>
                      <td className="p-4 text-center font-mono font-bold text-slate-800 text-sm">
                        {st.waterLevel}
                      </td>
                      <td className="p-4 text-center font-mono text-slate-500">
                        {st.bankLevel}
                      </td>
                      <td className="p-4 text-center">
                        <span
                          className={`inline-block text-[11px] font-bold px-2.5 py-1 rounded-full text-center min-w-[70px] ${
                            st.situation === "วิกฤต"
                              ? "bg-red-50 border border-red-200 text-red-600"
                              : st.situation === "เฝ้าระวัง"
                              ? "bg-amber-50 border border-amber-200 text-amber-600"
                              : "bg-emerald-50 border border-emerald-200 text-emerald-600"
                          }`}
                        >
                          {st.situation}
                        </span>
                      </td>
                      <td className="p-4 text-center font-bold text-slate-700">
                        <span
                          className={`px-1.5 py-0.5 rounded ${
                            st.trend === "เพิ่มขึ้น"
                              ? "text-red-500 bg-red-50"
                              : st.trend === "ลดลง"
                              ? "text-emerald-500 bg-emerald-50"
                              : "text-slate-500 bg-slate-50"
                          }`}
                        >
                          {st.trend}
                        </span>
                      </td>
                      <td className="p-4 text-center font-mono text-slate-400 text-[11px]">
                        {st.time}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
        <div className="p-4 border-t border-gray-150 bg-slate-50 flex items-center justify-between text-xs text-slate-500 font-mono">
          <span>แสดงสูงสุด 100 สถานี จากทั้งหมด {processedStations.length} รายการกรอง</span>
          <span>THAILAND FLOOD CONTROL METRICS</span>
        </div>
      </div>
    </div>
  );
}
