/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { AIChatMessage } from "../types.js";
import { MessageSquare, Send, Sparkles, AlertOctagon, HelpCircle, Activity } from "lucide-react";

export default function AiChatTab() {
  const [messages, setMessages] = useState<AIChatMessage[]>([
    {
      id: "ai-initial",
      sender: "ai",
      text: "สวัสดีครับ ยินดีต้อนรับสู่ศูนย์บริการช่วยเหลือ FLOODCARE AI ครับ! ผมคือผู้ช่วยด้านภัยพิบัติขั้นวิชาชีพ ประสิทธิภาพวิเคราะห์กู้ชีพ มุ่งมั่นคำนึงถึงความปลอดภัยของคุณเป็นหลัก\n\n- สอบถามข้อมูลความปลอดภัยหรือแนวทางปฏิบัติตนขณะเกิดอุทกภัยได้เลยครับ\n- หากคุณกำลังประสบเหตุฉุกเฉินด่วนคอขาดบาดตาย กรุณากดแจ้งศูนย์ SOS สีแดง หรือเร่งสายด่วน ปภ. 1784 ทันทีนะครับ",
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    }
  ]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || loading) return;

    const userMsgText = inputText;
    setInputText("");

    const userMessage: AIChatMessage = {
      id: "msg-" + Date.now(),
      sender: "user",
      text: userMsgText,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };

    setMessages((prev) => [...prev, userMessage]);
    setLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userMsgText })
      });

      if (!response.ok) {
        throw new Error("HTTP error " + response.status);
      }

      const data = await response.json();
      
      const aiMessage: AIChatMessage = {
        id: "ai-" + Date.now(),
        sender: "ai",
        text: data?.text || "ขออภัยด้วยครับ มีสัญญาณความขัดข้องระบบโทรมาตรชั่วคราว มีคำสั่งพาราเซลระดับด่วน 1784 รองรับอยู่เสมอครับ",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };

      setMessages((prev) => [...prev, aiMessage]);

    } catch (err) {
      console.error("AI chat error:", err);
      const errorMessage: AIChatMessage = {
        id: "ai-err-" + Date.now(),
        sender: "ai",
        text: "🚨 ระบบพิจารณาเกิดข้อขัดข้องชั่วขณะ ปัจจุบันเชื่อมต่อเครือข่ายจำกัด โปรดอพยพพิกัดขึ้นที่สูง และระมัดระวังกระแสไฟฟ้ารั่วตามขั้นตอนมาตรฐาน ปภ. 1784 ครับ",
        timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white border border-gray-200 rounded-2xl flex flex-col h-[calc(100vh-140px)] shadow-xs overflow-hidden">
      {/* Bot branding header */}
      <div className="bg-slate-900 text-slate-100 px-5 py-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-xl text-white shadow-md shadow-blue-500/20">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-sans font-bold text-sm text-white">FLOODCARE AI EXPERT</h3>
            <span className="text-[10px] font-mono text-emerald-400 flex items-center gap-1.5 mt-0.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              GEMINI MODEL ACTIVE
            </span>
          </div>
        </div>
        <div className="text-right text-[11px] text-slate-400 font-mono hidden sm:block">
          CALM & FIRM RESPONSE PROTOCOL
        </div>
      </div>

      {/* Message area */}
      <div className="flex-1 p-5 overflow-y-auto space-y-4 bg-slate-50/50">
        {messages.map((m) => {
          const isAi = m.sender === "ai";
          return (
            <div key={m.id} className={`flex ${isAi ? "justify-start" : "justify-end"} items-start gap-3`}>
              {isAi && (
                <div className="bg-slate-900 text-amber-500 p-2 rounded-lg text-xs font-bold font-mono">
                  FC
                </div>
              )}
              <div className="max-w-[80%] space-y-1">
                <div
                  className={`px-4 py-3 rounded-2xl text-xs sm:text-sm whitespace-pre-wrap leading-relaxed shadow-3xs ${
                    isAi
                      ? "bg-white text-slate-800 border border-gray-150 rounded-tl-none font-medium"
                      : "bg-blue-600 text-white rounded-tr-none font-semibold"
                  }`}
                >
                  {m.text}
                </div>
                <div className={`text-[10px] text-gray-400 font-mono ${!isAi ? "text-right" : ""}`}>
                  {m.timestamp}
                </div>
              </div>
            </div>
          );
        })}
        {loading && (
          <div className="flex justify-start items-center gap-3 animate-pulse">
            <div className="bg-slate-900 text-amber-500 p-2 rounded-lg text-xs font-bold font-mono">
              FC
            </div>
            <div className="bg-white border border-gray-150 px-4 py-3 rounded-2xl rounded-tl-none text-xs text-slate-500 font-medium">
              กำลังวิเคราะห์แผนที่และวางมาตรการช่วยเหลือ...
            </div>
          </div>
        )}
        <div ref={scrollRef}></div>
      </div>

      {/* Input Form */}
      <form onSubmit={handleSendMessage} className="p-4 border-t border-gray-150 bg-white flex items-center gap-2">
        <input
          id="ai-prompt-input"
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="พิมพ์คำถามที่ต้องการ เช่น วิธีรับมือน้ำป่าไหลหลาก, ประเมินระดับค่ายพักพิง..."
          className="flex-1 px-4 py-3 border border-gray-200 outline-none rounded-xl text-sm focus:border-blue-500 bg-gray-50 focus:bg-white transition"
        />
        <button
          id="send-ai-btn"
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-xl shadow-sm transition shrink-0"
        >
          <Send className="w-4 h-4 text-white" />
        </button>
      </form>
    </div>
  );
}
