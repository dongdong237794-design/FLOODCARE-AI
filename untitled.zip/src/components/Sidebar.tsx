/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import {
  LayoutDashboard,
  Droplets,
  AlertTriangle,
  PackageCheck,
  Users,
  MessageSquareCode,
  Smartphone,
  Shield,
  Activity
} from "lucide-react";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openSosCount: number;
  pendingNeedsCount: number;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  openSosCount,
  pendingNeedsCount
}: SidebarProps) {
  const navItems = [
    {
      id: "overview",
      label: "ภาพรวมศูนย์ประสานงาน",
      icon: LayoutDashboard,
      badge: null
    },
    {
      id: "water",
      label: "เฝ้าระวังระดับน้ำไทย",
      icon: Droplets,
      badge: "ThaiWater"
    },
    {
      id: "sos",
      label: "สถิติกู้ชีพและสั่งการ SOS",
      icon: AlertTriangle,
      badge: openSosCount > 0 ? `${openSosCount} เคส` : null,
      badgeColor: "bg-red-500 text-white font-bold"
    },
    {
      id: "needs",
      label: "ความช่วยเหลือเสบียง",
      icon: PackageCheck,
      badge: pendingNeedsCount > 0 ? `${pendingNeedsCount} รายการ` : null,
      badgeColor: "bg-amber-500 text-white"
    },
    {
      id: "profiles",
      label: "ข้อมูลลงทะเบียน LINE",
      icon: Users,
      badge: null
    },
    {
      id: "aichat",
      label: "ระบบ FLOODCARE AI",
      icon: MessageSquareCode,
      badge: "Gemini"
    },
    {
      id: "line_simulator",
      label: "จำลองขั้นตอนบอท LINE",
      icon: Smartphone,
      badge: "Test Bot"
    }
  ];

  return (
    <aside className="w-80 bg-slate-900 text-slate-100 flex flex-col h-screen border-r border-slate-800 shrink-0">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-800 flex items-center gap-3">
        <div className="bg-blue-600 p-2.5 rounded-xl shadow-md shadow-blue-500/20 text-white">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="font-sans font-bold text-lg tracking-tight text-white leading-none">
            FLOODCARE
          </h1>
          <span className="text-[10px] uppercase tracking-widest text-slate-400 font-mono flex items-center gap-1.5 mt-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse inline-block"></span>
            National Cmd Center
          </span>
        </div>
      </div>

      {/* Navigation list */}
      <nav className="flex-1 p-4 space-y-1.5 overflow-y-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              id={`tab-btn-${item.id}`}
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-3 rounded-lg transition-all duration-150 group text-left ${
                isActive
                  ? "bg-blue-600 text-white shadow-sm font-semibold"
                  : "text-slate-400 hover:bg-slate-800 hover:text-slate-100"
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-5 h-5 shrink-0 ${
                    isActive ? "text-white" : "text-slate-400 group-hover:text-slate-200"
                  }`}
                />
                <span className="text-sm font-medium tracking-tight truncate">
                  {item.label}
                </span>
              </div>
              {item.badge && (
                <span
                  className={`text-[10px] px-2 py-0.5 rounded-full font-sans tracking-wide shrink-0 ${
                    item.badgeColor || "bg-slate-850 text-slate-300 border border-slate-700"
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer statistics */}
      <div className="p-4 border-t border-slate-800 bg-slate-950 flex flex-col gap-1.5">
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
          <span>SERVER HEALTH:</span>
          <span className="text-emerald-400">100% ONLINE</span>
        </div>
        <div className="flex items-center justify-between text-[11px] font-mono text-slate-500">
          <span>CONNECTION:</span>
          <span className="text-blue-400">THAIWATER SECURE</span>
        </div>
      </div>
    </aside>
  );
}
