/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { RegisteredUser } from "../types.js";
import { Users, Search, UserCheck, Phone, Calendar, ShieldCheck } from "lucide-react";

interface ProfilesTabProps {
  users: RegisteredUser[];
}

export default function ProfilesTab({ users }: ProfilesTabProps) {
  const [search, setSearch] = useState("");

  const filtered = users.filter((u) => {
    return (
      u.firstName.toLowerCase().includes(search.toLowerCase()) ||
      u.lastName.toLowerCase().includes(search.toLowerCase()) ||
      u.phone.includes(search) ||
      u.userId.toLowerCase().includes(search.toLowerCase())
    );
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="pb-4 border-b border-gray-100">
        <h2 className="text-2xl font-sans font-bold text-slate-800 tracking-tight flex items-center gap-2">
          <Users className="w-6.5 h-6.5 text-blue-600" />
          ฐานคู่สาย LINE ผู้ลงทะเบียนล่วงหน้า
        </h2>
        <p className="text-sm text-slate-500 mt-1">
          รายชื่อ สมาชิก และพิกัดเบอร์โทรติดต่อผู้เดือดร้อนที่แอดคู่สายบอทกู้ชีพเข้ามาในระบบเพื่อความสะดวกในการระบายประเด็น
        </p>
      </div>

      {/* Control bar */}
      <div className="bg-white border border-gray-150 p-4 rounded-xl flex items-center gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            id="profiles-search"
            type="text"
            placeholder="ค้นหาชื่อนามสกุล, เบอร์โทร, หรือรหัสคู่สาย..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm bg-gray-50 outline-none focus:ring-1 focus:ring-blue-500 focus:bg-white transition"
          />
        </div>
      </div>

      {/* Table List */}
      <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-gray-100 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="p-4">รหัสคู่สาย (LINE ID)</th>
                <th className="p-4">ชื่อผู้ลงทะเบียน</th>
                <th className="p-4">เบอร์โทรศัพท์ติดต่อ</th>
                <th className="p-4 text-center">วันที่ลงทะเบียน</th>
                <th className="p-4 text-center">สถานะใช้งาน</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-150 text-xs text-slate-700">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-8 text-center text-slate-400">
                    ❌ ไม่พบรายชื่อผู้ใช้ที่ลงทะเบียนด้วยคีย์เวิร์ดนี้
                  </td>
                </tr>
              ) : (
                filtered.map((user) => (
                  <tr key={user.userId} className="hover:bg-slate-50/50 transition">
                    <td className="p-4 font-mono font-bold text-slate-500">{user.userId}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="bg-blue-50 text-blue-600 p-1.5 rounded-full">
                          <UserCheck className="w-4 h-4" />
                        </div>
                        <span className="font-bold text-slate-800 text-sm">
                          {user.firstName} {user.lastName}
                        </span>
                      </div>
                    </td>
                    <td className="p-4">
                      <a
                        href={`tel:${user.phone}`}
                        className="font-mono font-bold text-slate-800 flex items-center gap-1 hover:underline"
                      >
                        <Phone className="w-3.5 h-3.5 text-blue-500" />
                        {user.phone}
                      </a>
                    </td>
                    <td className="p-4 text-center font-mono text-slate-500">
                      <div className="flex items-center justify-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        {user.registerDate}
                      </div>
                    </td>
                    <td className="p-4 text-center">
                      <span className="inline-block text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-full uppercase">
                        <ShieldCheck className="w-3 h-3 text-emerald-600 inline mr-1" />
                        {user.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
