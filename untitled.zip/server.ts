/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { WaterStation, RegisteredUser, SOSRequest, UserNeed } from "./src/types";

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json());

// Persistent simulated database path
const DB_DIR = path.join(process.cwd(), "data");
const DB_PATH = path.join(DB_DIR, "db.json");

// Ensure data folder exists
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

// Initial major fallback/seed water stations representing real geography in Thailand
const CORE_FALLBACK_STATIONS: WaterStation[] = [
  {
    stationCode: "C2",
    name: "สถานีท้ายเขื่อนภูมิพล (แม่น้ำปิง)",
    river: "แม่น้ำปิง",
    location: "เชียงใหม่",
    lat: 18.7885,
    lon: 98.9950,
    waterLevel: 1.55,
    bankLevel: 3.70,
    situation: "ปกติ",
    trend: "คงที่",
    time: "2026-06-16 08:30"
  },
  {
    stationCode: "C29A",
    name: "สถานีวัดระดับน้ำสะพานพุทธ (แม่น้ำเจ้าพระยา)",
    river: "แม่น้ำเจ้าพระยา",
    location: "กรุงเทพมหานคร",
    lat: 13.7390,
    lon: 100.4985,
    waterLevel: 1.85,
    bankLevel: 3.50,
    situation: "ปกติ",
    trend: "ลดลง",
    time: "2026-06-16 08:40"
  },
  {
    stationCode: "C35",
    name: "สถานีบางบาล (แม่น้ำเจ้าพระยา)",
    river: "แม่น้ำเจ้าพระยา",
    location: "พระนครศรีอยุธยา",
    lat: 14.3565,
    lon: 100.5580,
    waterLevel: 3.12,
    bankLevel: 4.80,
    situation: "เฝ้าระวัง",
    trend: "เพิ่มขึ้น",
    time: "2026-06-16 08:10"
  },
  {
    stationCode: "M7",
    name: "สถานีสะพานเสรีประชาธิปไตย (แม่น้ำมูล)",
    river: "แม่น้ำมูล",
    location: "อุบลราชธานี",
    lat: 15.2280,
    lon: 104.8560,
    waterLevel: 110.15,
    bankLevel: 112.50,
    situation: "เฝ้าระวัง",
    trend: "คงที่",
    time: "2026-06-16 08:20"
  },
  {
    stationCode: "UT1",
    name: "สถานีลุ่มน้ำคลองอู่ตะเภา (หาดใหญ่)",
    river: "คลองอู่ตะเภา",
    location: "สงขลา",
    lat: 7.0125,
    lon: 100.4560,
    waterLevel: 4.82,
    bankLevel: 5.00,
    situation: "วิกฤต",
    trend: "เพิ่มขึ้น",
    time: "2026-06-16 08:45"
  },
  {
    stationCode: "E20",
    name: "สถานีกบินทร์บุรี (แม่น้ำปราจีนบุรี)",
    river: "แม่น้ำปราจีนบุรี",
    location: "ปราจีนบุรี",
    lat: 13.9930,
    lon: 101.7180,
    waterLevel: 8.65,
    bankLevel: 9.20,
    situation: "ปกติ",
    trend: "ลดลง",
    time: "2026-06-16 08:00"
  },
  {
    stationCode: "P67",
    name: "สถานีแม่น้ำโก-ลก (สะพานลันตู)",
    river: "แม่น้ำโก-ลก",
    location: "นราธิวาส",
    lat: 6.0240,
    lon: 101.9680,
    waterLevel: 9.15,
    bankLevel: 8.50,
    situation: "วิกฤต",
    trend: "เพิ่มขึ้น",
    time: "2026-06-16 08:35"
  },
  {
    stationCode: "Y1C",
    name: "สถานีศรีสัชนาลัย (แม่น้ำยม)",
    river: "แม่น้ำยม",
    location: "สุโขทัย",
    lat: 17.5180,
    lon: 99.8240,
    waterLevel: 5.12,
    bankLevel: 7.50,
    situation: "ปกติ",
    trend: "คงที่",
    time: "2026-06-16 08:15"
  },
  {
    stationCode: "W3A",
    name: "สถานีสามง่าม (แม่น้ำยม)",
    river: "แม่น้ำยม",
    location: "พิจิตร",
    lat: 16.5120,
    lon: 100.2080,
    waterLevel: 8.42,
    bankLevel: 9.10,
    situation: "เฝ้าระวัง",
    trend: "เพิ่มขึ้น",
    time: "2026-06-16 08:25"
  },
  {
    stationCode: "N5A",
    name: "สถานีเมืองพิษณุโลก (แม่น้ำน่าน)",
    river: "แม่น้ำน่าน",
    location: "พิษณุโลก",
    lat: 16.8220,
    lon: 100.2580,
    waterLevel: 4.88,
    bankLevel: 10.30,
    situation: "ปกติ",
    trend: "ลดลง",
    time: "2026-06-16 08:30"
  }
];

// Seed databases
interface SchemaDB {
  users: RegisteredUser[];
  sosRequests: SOSRequest[];
  userNeeds: UserNeed[];
  stationsCache: WaterStation[];
  lastSyncTime: string;
}

let dbMemory: SchemaDB = {
  users: [
    {
      userId: "U123456781",
      firstName: "สมชาย",
      lastName: "ใจดี",
      phone: "0812345678",
      registerDate: "2026-06-15",
      status: "ACTIVE"
    },
    {
      userId: "U123456782",
      firstName: "สมศรี",
      lastName: "รักษ์ดี",
      phone: "0898765432",
      registerDate: "2026-06-16",
      status: "ACTIVE"
    }
  ],
  sosRequests: [
    {
      requestId: "SOS-20260616-1024",
      userId: "U123456781",
      userName: "สมชาย ใจดี",
      phone: "0812345678",
      timestamp: "2026-06-16 06:12:45",
      latitude: 14.3580,
      longitude: 100.5590,
      groupTypes: ["ผู้ป่วยติดเตียง/พิการ", "ผู้ใหญ่ทั่วไป"],
      urgencyLevel: "🔴 วิกฤต (มิดหัว/ติดบนหลังคา)",
      note: "ต้องการเรือด่วนระดับน้ำเกือบถึงชั้น 2 แล้ว แบตมือถือเหลือ 10%",
      priority: "CRITICAL",
      status: "OPEN"
    },
    {
      requestId: "SOS-20260616-2241",
      userId: "U123456782",
      userName: "สมศรี รักษ์ดี",
      phone: "0898765432",
      timestamp: "2026-06-16 07:15:30",
      latitude: 7.0145,
      longitude: 100.4595,
      groupTypes: ["มีเด็กเล็ก/คนชรา"],
      urgencyLevel: "🟠 สูง (ระดับอก/เกิน 1 เมตร)",
      note: "บ้านคนแก่อยู่คนเดียว มีน้ำล้อมสายไฟตัดหมดแล้ว มืดมากขอไฟฉายด้วยค่ะ",
      priority: "HIGH",
      status: "IN_PROGRESS",
      responderName: "กู้ภัยพระร่วง สงขลา",
      responderNotes: "กำลังส่งเรือไฟเบอร์กลาสและทีมงานเข้าไปพร้อมเสื้อชูชีพ",
      acceptedAt: "2026-06-16 07:45:00"
    }
  ],
  userNeeds: [
    {
      id: "NEED-001",
      userId: "U123456781",
      userName: "สมชาย ใจดี",
      phone: "0812345678",
      timestamp: "2026-06-16 07:30:00",
      latitude: 14.3582,
      longitude: 100.5592,
      categories: ["🍲 อาหาร/น้ำดื่ม", "ยารักษาโรค/เวชภัณฑ์"],
      details: "ขอน้ำดื่ม 3 แพ็ค ยาพารา และชุดทำแผลด่วนครับ",
      urgency: "ด่วนมาก (หมดแล้ว)",
      status: "PENDING"
    }
  ],
  stationsCache: CORE_FALLBACK_STATIONS,
  lastSyncTime: ""
};

// Load database if exists
if (fs.existsSync(DB_PATH)) {
  try {
    const raw = fs.readFileSync(DB_PATH, "utf-8");
    const parsed = JSON.parse(raw);
    dbMemory = { ...dbMemory, ...parsed };
  } catch (e) {
    console.error("Error reading database fallback to seeds:", e);
  }
} else {
  saveDB();
}

function saveDB() {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(dbMemory, null, 2), "utf-8");
  } catch (e) {
    console.error("Error saving database:", e);
  }
}

// Distance helper
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number) {
  const R = 6371; // Earth's radius in km
  const dlat = ((lat2 - lat1) * Math.PI) / 180;
  const dlon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dlat / 2) * Math.sin(dlat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dlon / 2) *
      Math.sin(dlon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Lazy init Gemini SDK
let genAIClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!genAIClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === "MY_GEMINI_API_KEY") {
      throw new Error("GEMINI_API_KEY is not configured inside AI Studio secrets.");
    }
    genAIClient = new GoogleGenAI({ apiKey: key });
  }
  return genAIClient;
}

// Defensive, robust ThaiWater API syncer
async function fetchAndParseThaiWater(): Promise<WaterStation[]> {
  const url = "https://api-v3.thaiwater.net/api/v1/thaiwater30/public/waterlevel_load";
  try {
    console.log(`[ThaiWater API] Pulling actual live water data from: ${url}`);
    const response = await fetch(url, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "application/json"
      },
      signal: AbortSignal.timeout(10000) // 10 second timeout
    });

    if (!response.ok) {
      throw new Error(`ThaiWater API returned non-200 state: ${response.status}`);
    }

    const json = await response.json();
    console.log(`[ThaiWater API] Successfully downloaded live packet. Parsing recursively...`);

    // Resilient scanner to find array list
    let rawList: any[] = [];
    if (Array.isArray(json)) {
      rawList = json;
    } else if (json && typeof json === "object") {
      // Look for any array inside keys
      for (const key of Object.keys(json)) {
        if (Array.isArray(json[key])) {
          rawList = json[key];
          console.log(`[ThaiWater API] Found station key list: "${key}" with length ${rawList.length}`);
          break;
        }
      }
      // Or search deeply nested
      if (rawList.length === 0 && json.data && typeof json.data === "object") {
        for (const key of Object.keys(json.data)) {
          if (Array.isArray(json.data[key])) {
            rawList = json.data[key];
            console.log(`[ThaiWater API] Found nested data key list: "${key}" with length ${rawList.length}`);
            break;
          }
        }
      }
    }

    if (rawList.length === 0) {
      throw new Error("Could not automatically locate the data array structure in ThaiWater reply packet.");
    }

    // Now map raw items
    const parsedStations: WaterStation[] = [];
    for (const item of rawList) {
      try {
        // Find nested properties if exists
        const stObj = item.station || item.stationMetadata || item;
        
        // Match code
        const stationCode = String(
          stObj.station_code || stObj.station_id || stObj.code || stObj.id || item.stationCode || item.id || ""
        );
        if (!stationCode) continue;

        // Match Name
        const name = String(
          stObj.station_name_th || stObj.name_th || stObj.station_name || stObj.name || item.stationName || ""
        );

        // Match River
        const river = String(
          stObj.river_name_th || stObj.river_name || stObj.river || item.riverName || item.river || "ไม่ระบุแม่น้ำ"
        );

        // Match Location (Province)
        const location = String(
          stObj.province_name_th || stObj.province_name || stObj.provinceName || stObj.province || item.provinceName || item.location || "ไม่ระบุจังหวัด"
        );

        // Match coordinates
        const lat = parseFloat(stObj.lat || stObj.latitude || stObj.station_latitude || item.latitude || 0);
        const lon = parseFloat(stObj.lon || stObj.longitude || stObj.station_longitude || stObj.longitude || item.longitude || 0);
        if (lat === 0 || lon === 0) continue;

        // Water level (current)
        const rawWater = item.water_level || item.wl || item.value || item.waterLevel || "";
        const waterLevel = rawWater !== "" ? parseFloat(rawWater) : "-";

        // Bank level (height)
        const rawBank = item.bank_height || item.bank_level || item.bankLevel || item.bank_height_m || "";
        const bankLevel = rawBank !== "" ? parseFloat(rawBank) : "-";

        // Calculate situation if not present
        let situation = String(item.situation || item.situation_name || item.status || "").trim();
        if (!situation || situation === "-" || situation === "undefined") {
          if (typeof waterLevel === "number" && typeof bankLevel === "number" && bankLevel > 0) {
            const ratio = waterLevel / bankLevel;
            if (ratio >= 0.95 || waterLevel >= bankLevel) {
              situation = "วิกฤต";
            } else if (ratio >= 0.70) {
              situation = "เฝ้าระวัง";
            } else {
              situation = "ปกติ";
            }
          } else {
            situation = "ปกติ";
          }
        }

        // Determine trend
        let trend = String(item.trend || item.trend_name || "").trim();
        if (!trend || trend === "-" || trend === "undefined") {
          trend = "คงที่";
        }

        // Time
        const time = String(item.time || item.datetime || item.date || item.updated_at || item.measured_at || new Date().toISOString().slice(0,16).replace("T", " "));

        parsedStations.push({
          stationCode,
          name,
          river,
          location,
          lat,
          lon,
          waterLevel,
          bankLevel,
          situation,
          trend,
          time
        });
      } catch (innerErr) {
        // Skip individual corrupted item
      }
    }

    if (parsedStations.length === 0) {
      throw new Error("Data mapping yielded 0 valid parsed water level records.");
    }

    console.log(`[ThaiWater API] Successfully mapped ${parsedStations.length} clean water stations.`);
    return parsedStations;

  } catch (err) {
    console.error("[ThaiWater API] LIVE SYNC ERROR:", err);
    throw err;
  }
}

// --- API ROUTES ---

// Trigger Manual Sync
app.post("/api/thaiwater/sync", async (req, res) => {
  try {
    const list = await fetchAndParseThaiWater();
    dbMemory.stationsCache = list;
    dbMemory.lastSyncTime = new Date().toLocaleString("th-TH");
    saveDB();
    res.json({ success: true, count: list.length, lastSyncTime: dbMemory.lastSyncTime });
  } catch (error: any) {
    res.status(500).json({ success: false, message: error?.message || "Sync failed" });
  }
});

// Fetch Stations
app.get("/api/thaiwater/stations", (req, res) => {
  const { clat, clon } = req.query;
  let stations = dbMemory.stationsCache || CORE_FALLBACK_STATIONS;

  if (clat && clon) {
    const userLat = parseFloat(clat as string);
    const userLon = parseFloat(clon as string);
    if (!isNaN(userLat) && !isNaN(userLon)) {
      // Include distance and sort
      const measured = stations.map(st => ({
        ...st,
        distance: calculateDistance(userLat, userLon, st.lat, st.lon)
      }));
      measured.sort((a, b) => a.distance - b.distance);
      return res.json(measured);
    }
  }

  res.json(stations);
});

// Profiles
app.get("/api/profiles", (req, res) => {
  res.json(dbMemory.users);
});

app.post("/api/profiles", (req, res) => {
  const { firstName, lastName, phone } = req.body;
  if (!firstName || !lastName || !phone) {
    return res.status(400).json({ error: "Missing required fields" });
  }
  const newUser: RegisteredUser = {
    userId: "MOCK-" + Math.floor(Math.random() * 899999 + 100000),
    firstName,
    lastName,
    phone,
    registerDate: new Date().toISOString().slice(0, 10),
    status: "ACTIVE"
  };
  dbMemory.users.unshift(newUser);
  saveDB();
  res.json(newUser);
});

// SOS
app.get("/api/sos/requests", (req, res) => {
  res.json(dbMemory.sosRequests);
});

app.post("/api/sos/requests", (req, res) => {
  const { userId, userName, phone, latitude, longitude, groupTypes, urgencyLevel, note, photoUrl } = req.body;
  if (!latitude || !longitude || !groupTypes || !urgencyLevel) {
    return res.status(400).json({ error: "Missing required coordinates, groups or urgency fields" });
  }

  // Calculate priority backend logic
  // CRITICAL: มีผู้บาดเจ็บ OR ผู้ป่วยติดเตียง OR น้ำระดับวิกฤต OR ขาดแคลนยาหนัก
  // HIGH: มีเด็ก/คนชรา OR น้ำระดับสูง
  let priority: "CRITICAL" | "HIGH" | "NORMAL" = "NORMAL";
  const strGroups = groupTypes.join(",").toLowerCase();
  const strUrgency = urgencyLevel.toLowerCase();

  if (
    strGroups.includes("ผู้ป่วยติดเตียง/พิการ") ||
    strGroups.includes("ผู้ป่วย") ||
    strGroups.includes("พิการ") ||
    strGroups.includes("บาดเจ็บ") ||
    strUrgency.includes("วิกฤต") ||
    strUrgency.includes("หลากวิกฤต") ||
    strUrgency.includes("ขาดแคลนยา")
  ) {
    priority = "CRITICAL";
  } else if (
    strGroups.includes("เด็ก") ||
    strGroups.includes("ชรา") ||
    strGroups.includes("คนชรา") ||
    strUrgency.includes("สูง")
  ) {
    priority = "HIGH";
  }

  const newSOS: SOSRequest = {
    requestId: "SOS-" + new Date().toISOString().slice(0,10).replace(/-/g, "") + "-" + Math.floor(Math.random() * 8999 + 1000),
    userId: userId || "ANONYMOUS",
    userName: userName || "ผู้ประสบภัยนิรนาม",
    phone: phone || "ไม่ระบุเบอร์",
    timestamp: new Date().toISOString().replace("T", " ").slice(0, 19),
    latitude: parseFloat(latitude),
    longitude: parseFloat(longitude),
    groupTypes,
    urgencyLevel,
    photoUrl: photoUrl || "",
    note: note || "",
    priority,
    status: "OPEN"
  };

  dbMemory.sosRequests.unshift(newSOS);
  saveDB();
  res.json(newSOS);
});

app.post("/api/sos/requests/:id/accept", (req, res) => {
  const { id } = req.params;
  const { responderName, responderNotes } = req.body;
  const reqObj = dbMemory.sosRequests.find(r => r.requestId === id);
  if (!reqObj) {
    return res.status(404).json({ error: "SOS not found" });
  }
  reqObj.status = "IN_PROGRESS";
  reqObj.responderName = responderName || "เจ้าหน้าที่ศูนย์ระวังภัยร่วม";
  reqObj.responderNotes = responderNotes || "กำลังประสานเรือกู้ชีพประจำการด่วน";
  reqObj.acceptedAt = new Date().toISOString().replace("T", " ").slice(0, 19);
  saveDB();
  res.json(reqObj);
});

app.post("/api/sos/requests/:id/resolve", (req, res) => {
  const { id } = req.params;
  const { notes } = req.body;
  const reqObj = dbMemory.sosRequests.find(r => r.requestId === id);
  if (!reqObj) {
    return res.status(404).json({ error: "SOS not found" });
  }
  reqObj.status = "RESOLVED";
  reqObj.responderNotes = notes || "ช่วยเหลือ อพยพ นำส่งศูนย์พักพิงพบลำน้ำปลอดภัยเรียบร้อยแล้ว";
  reqObj.resolvedAt = new Date().toISOString().replace("T", " ").slice(0, 19);
  saveDB();
  res.json(reqObj);
});

// User Needs
app.get("/api/needs", (req, res) => {
  res.json(dbMemory.userNeeds);
});

app.post("/api/needs", (req, res) => {
  const { userId, userName, phone, latitude, longitude, categories, details, urgency } = req.body;
  if (!latitude || !longitude || !categories) {
    return res.status(400).json({ error: "Missing coordinates, category selection" });
  }
  const newNeed: UserNeed = {
    id: "NEED-" + Math.floor(Math.random() * 89999 + 10000),
    userId: userId || "ANONYMOUS",
    userName: userName || "ผู้เดือดร้อน",
    phone: phone || "ไม่ระบุเบอร์",
    timestamp: new Date().toISOString().replace("T", " ").slice(0, 19),
    latitude: parseFloat(latitude),
    longitude: parseFloat(longitude),
    categories,
    details: details || "",
    urgency: urgency || "ปานกลาง",
    status: "PENDING"
  };
  dbMemory.userNeeds.unshift(newNeed);
  saveDB();
  res.json(newNeed);
});

app.post("/api/needs/:id/complete", (req, res) => {
  const { id } = req.params;
  const need = dbMemory.userNeeds.find(n => n.id === id);
  if (!need) {
    return res.status(404).json({ error: "Need not found" });
  }
  need.status = "COMPLETED";
  saveDB();
  res.json(need);
});

// AI Chat Proxy with Lazy Gemini integration and Crisis Detection
app.post("/api/chat", async (req, res) => {
  const { message } = req.body;
  if (!message) {
    return res.status(400).json({ error: "Message cannot be empty." });
  }

  // Keyword check for urgent high-risk emergency detection
  const lowerMsg = message.toLowerCase();
  const isEmergency =
    lowerMsg.includes("ช่วยด้วย") ||
    lowerMsg.includes("จะจม") ||
    lowerMsg.includes("ไฟดูด") ||
    lowerMsg.includes("หายใจไม่ออก") ||
    lowerMsg.includes("ติดบนหลังคา") ||
    lowerMsg.includes("เจ็บป่วยฉุกเฉิน") ||
    lowerMsg.includes("ไม่มีอาหารเลย") ||
    lowerMsg.includes("น้ำท่วมมิด");

  if (isEmergency) {
    return res.json({
      text: "🚨 ภัยพิบัติฉุกเฉินความปลอดภัยระดับสูงสุด! โปรดปฏิบัติตามขั้นตอนเอาชีวิดรอดทันที:\n\n1. ตัดสะพานไฟเบรกเกอร์ทันที ห้ามสัมผัสเครื่องใช้ไฟที่มีน้ำขังนอง\n2. อพยพขึ้นชั้นบนหรือบนหลังคาในจุดสง่าสายตา มองเห็นง่ายทางอากาศและเรือกู้ภัย\n3. โทร ปภ. ด่วนที่สุดที่หมายเลขสายด่วน 1784 หรือเจ็บป่วยขั้นแพทย์ โทร 1669 ทันที!\n\nเจ้าหน้าที่บนแดชบอร์ด FloodCare ชุดกู้ชีพได้มองเห็นสัญญานแล้ว โปรดประหยัดแบตเตอรี่ของคุณด้วยการปิดแอปพลิเคชันที่ไม่จำเป็นนะครับ! FloodCare AI เอาใจช่วยและคุ้มกันคุณตลอดยี่สิบสี่ชั่วโมงครับ"
    });
  }

  // Try using Gemini GenAI
  try {
    const ai = getGenAI();
    const systemPrompt = `คุณคือ FLOODCARE AI ผู้ช่วยกู้ภัยมืออาชีพประจำศูนย์ประสานงานภัยน้ำท่วมระดับชาติ มีบทบาทเป็นผู้นำในวิกฤตที่ใจดีแต่เด็ดขาด ให้คำแนะนำด้านการเอาชีวิตรอดและการรับมือภัยน้ำท่วม ด้วยข้อมูลที่แม่นยำและตรงประเด็นเสมอ

กฎเหล็กในการตอบและจัดรูปแบบข้อความเพื่อนำไปแสดงผลบน LINE App หรือ Web UI:
1. น้ำเสียงและสรรพนาม: ใช้โทนเสียงที่เป็นใจดีแต่เด็ดขาด (Calm and Firm) ให้ความรู้สึกมั่นใจและปลอดภัย ใช้คำลงท้ายว่า 'ครับ' หรือ 'นะครับ' เป็นหลัก หลีกเลี่ยงการสะกดสแลช เช่น 'ครับ/ค่ะ' หรือ 'นะครับ/คะ'
2. ความกระชับและลำดับความสำคัญ: ข้อมูลสำคัญที่สุดต้องอยู่ใน 3 บรรทัดแรกเสมอ เน้นการสั่งการเป็นขั้นตอน (1, 2, 3) แทนการพูดคลุมเครือ เช่น '1. ยกเบรกเกอร์ 2. ขึ้นที่สูง 3. เตรียมไฟฉาย'
3. การตรวจจับความเร่งด่วน (Emergency Detection): หากผู้ใช้ส่งข้อความที่มีคำสำคัญบ่งบอกถึงอันตรายถึงชีวิต เช่น 'ช่วยด้วย' 'จะจมแล้ว' 'ไฟดูด' 'หายใจไม่ออก' หยุดการเกริ่นนำทันที ส่งขั้นตอนเอาตัวรอดพร้อมเบอร์ฉุกเฉิน 1784 หรือ 1669 เป็นอันดับแรก จากนั้นค่อยถามรายละเอียดเพิ่มเติม
4. Data-Driven Response: ให้ความสำคัญกับข้อมูลจากระบบก่อนเสมอ หากผู้ใช้ถามถึงสถานที่ที่ไม่มีในฐานข้อมูล ให้ยอมรับว่า 'ไม่มีข้อมูลในระบบ' และแนะนำให้ดูลิงก์แผนที่รวมแทนการเดาพิกัดเอง
5. กฎศูนย์พักพิงและเส้นทาง: ห้ามยืนยันว่าเส้นทางปลอดภัย 100% เพราะระดับน้ำเปลี่ยนตลอดเวลา ต้องมีประโยคเตือนเสมอว่า 'โปรดใช้ความระมัดระวังในการเดินทางและสังเกตระดับน้ำจริงหน้างาน'
6. รูปแบบสัญลักษณ์: ห้ามใช้เครื่องหมายดอกจัน (*) ในการทำสัญลักษณ์หัวข้อย่อยหรือเน้นคำ ให้ใช้อิโมจิที่แสดงอารมณ์อบอุ่นแทน (เช่น 📌 🏃 🩹 📞 ⚠️ 🟢 🔴) ใช้การเว้นบรรทัด (Spacing) เพื่อแยกหัวข้อแทนการใช้ตัวหนา
7. ความปลอดภัยสูงสุด: ห้ามเดาข้อมูลหรือจินตนาการสิ่งที่ไม่เป็นความจริงเด็ดขาด หากข้อมูลใดไม่แน่ชัด ให้แสดงความห่วงใจและแนะนำเบอร์โทรสายด่วนที่ถูกต้องทันที`;

    const model = "gemini-2.5-flash";
    const response = await ai.models.generateContent({
      model: model,
      contents: message,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.3
      }
    });

    const cleanReply = response.text
      ? response.text.replace(/\*\*/g, "").replace(/\*/g, "")
      : "ขออภัยด้วยครับ ระบบประมวลผลคำตอบขัดข้องชั่วคราว โปรดประสานแพทย์ 1669 หรือแจ้งกู้ภัย 1784 ทันทีครับ";

    res.json({ text: cleanReply });

  } catch (err: any) {
    console.error("[Gemini AI Error]", err);
    // Safe friendly fallback
    res.json({
      text: "🤖 ยินดีต้อนรับสู่ศูนย์บริการ FLOODCARE AI ครับ! แนะนำให้หลีกเลี่ยงกระแสน้ำเข้าชั้นตึก และหากต้องการความช่วยเหลือด่วนสามารถกดปุ่มแดง 'SOS ขอความช่วยเหลือ' บนหน้าหลัก หรือโทรศัพท์สายด่วนนิรภัยกรมป้องกันบรรเทาสาธารณภัย 1784 ตลอด 24 ชม. ครับ"
    });
  }
});

// Setup development and production middlewares
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running professionally on http://localhost:${PORT}`);
  });
}

startServer();
